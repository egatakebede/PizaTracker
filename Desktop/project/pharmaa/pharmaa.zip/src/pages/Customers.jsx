import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useTheme } from "../components/ThemeContext";
import MedicalParticles from "../components/MedicalParticles"; // Updated import
import TiltCard from "./TiltCard"; // Use the real TiltCard for consistency

// --- Helper Components & Hooks ---
const useScript = (src) => {
  const [status, setStatus] = useState(src ? "loading" : "idle");
  useEffect(() => {
    if (!src) { setStatus("idle"); return; }
    let script = document.querySelector(`script[src="${src}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.setAttribute("data-status", "loading");
      document.body.appendChild(script);
      const setAttributeFromEvent = (event) => {
        script.setAttribute("data-status", event.type === "load" ? "ready" : "error");
      };
      script.addEventListener("load", setAttributeFromEvent);
      script.addEventListener("error", setAttributeFromEvent);
    } else {
      setStatus(script.getAttribute("data-status"));
    }
    const setStateFromEvent = (event) => {
      setStatus(event.type === "load" ? "ready" : "error");
    };
    script.addEventListener("load", setStateFromEvent);
    script.addEventListener("error", setStateFromEvent);
    return () => {
      if (script) {
        script.removeEventListener("load", setStateFromEvent);
        script.removeEventListener("error", setStateFromEvent);
      }
    };
  }, [src]);
  return status;
};

const MapComponent = ({ location, zoom = 15 }) => {
  const mapRef = useRef(null);
  const leafletStatus = useScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');
  useEffect(() => {
    if (leafletStatus !== 'ready' || !location || !mapRef.current || !window.L) return;
    const map = window.L.map(mapRef.current).setView([location.lat, location.lng], zoom);
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    window.L.marker([location.lat, location.lng]).addTo(map);
    return () => map.remove();
  }, [leafletStatus, location, zoom]);
  return <div ref={mapRef} style={{ height: '200px', width: '100%' }} />;
};

const CustomerProfileModal = ({ isOpen, onClose, customer, onSendMessage }) => {
  if (!isOpen || !customer) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg rounded-xl shadow-2xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white p-6">
        <h3 className="text-lg font-semibold mb-4">Customer Profile</h3>
        <div className="flex items-center gap-4 mb-4">
          <img src={customer.avatarUrl} alt={customer.name} className="w-20 h-20 rounded-full" />
          <div>
            <h4 className="text-xl font-bold">{customer.name}</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">Joined: {customer.joinDate}</p>
          </div>
        </div>
        <div className="space-y-2 text-sm">
          <p><span className="font-semibold">Total Orders:</span> {customer.totalOrders}</p>
          <p><span className="font-semibold">Total Spent:</span> ${customer.totalSpent.toFixed(2)}</p>
          <p><span className="font-semibold">Last Activity:</span> {customer.lastActivity}</p>
        </div>
        <button
          onClick={() => onSendMessage(customer)}
          className="mt-4 w-full rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
        >
          Send Message
        </button>
      </div>
    </div>
  );
};

// --- Main Customers Component ---
function CustomersComponent() {
  const { theme } = useTheme();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState("name");
  const [modalOpen, setModalOpen] = useState(false);
  const [viewingCustomer, setViewingCustomer] = useState(null);

  const customers = useMemo(() => [
    {
      id: 1,
      name: "Alice Brown",
      avatarUrl: "https://placehold.co/100x100",
      joinDate: "2025-01-15",
      totalOrders: 12,
      totalSpent: 450.75,
      lastActivity: "2025-09-10",
    },
    {
      id: 2,
      name: "Bob Smith",
      avatarUrl: "https://placehold.co/100x100",
      joinDate: "2025-03-22",
      totalOrders: 8,
      totalSpent: 320.50,
      lastActivity: "2025-09-12",
    },
    // Add more mock data as needed
  ], []);

  const sortedAndFilteredCustomers = useMemo(() => {
    return customers
      .filter((c) =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => {
        if (sortKey === "name") return a.name.localeCompare(b.name);
        if (sortKey === "joinDate") return new Date(a.joinDate) - new Date(b.joinDate);
        if (sortKey === "totalSpent") return b.totalSpent - a.totalSpent;
        return 0;
      });
  }, [customers, searchTerm, sortKey]);

  const handleViewProfile = (customer) => {
    setViewingCustomer(customer);
    setModalOpen(true);
  };

  const handleSendMessage = (customer) => {
    console.log(`Sending message to ${customer.name}`);
  };

  return (
    <div className={`relative flex flex-col h-screen p-6 ${theme === 'dark' ? 'text-gray-200' : 'text-gray-800'}`}>
      <MedicalParticles variant="default" /> {/* Updated to real component */}
      <div className="relative z-10 flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold text-blue-600">Customers</h1>
      </div>
      <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <input
          type="text"
          placeholder="Search by customer name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full sm:w-1/2 rounded-md border bg-transparent px-3 py-2 text-sm dark:border-gray-700"
        />
        <select
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value)}
          className="w-full sm:w-auto rounded-md border bg-transparent px-3 py-2 text-sm dark:border-gray-700"
        >
          <option value="name">Sort by Name</option>
          <option value="joinDate">Sort by Join Date</option>
          <option value="totalSpent">Sort by Total Spent</option>
        </select>
      </div>
      <div className="relative z-10 flex-1 overflow-y-auto pr-2">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 auto-rows-min">
          {sortedAndFilteredCustomers.map((c) => (
            <TiltCard
              key={c.id}
              onClick={() => handleViewProfile(c)}
              className={`rounded-xl p-5 shadow-lg border transition-all hover:shadow-2xl hover:-translate-y-1 cursor-pointer ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}
            >
              <div className="flex items-center gap-4 mb-4">
                <img src={c.avatarUrl} alt={c.name} className="w-16 h-16 rounded-full" />
                <div>
                  <h2 className="text-lg font-semibold">{c.name}</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Joined: {c.joinDate}</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Orders:</span>
                  <span className="font-semibold">{c.totalOrders}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Spent:</span>
                  <span className="font-semibold">${c.totalSpent.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Activity:</span>
                  <span className="font-semibold">{c.lastActivity}</span>
                </div>
              </div>
            </TiltCard>
          ))}
        </div>
      </div>
      <CustomerProfileModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        customer={viewingCustomer}
        onSendMessage={handleSendMessage}
      />
    </div>
  );
}

// --- Main App Component ---
export default CustomersComponent; 