import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Moon, Sun, FileText } from 'lucide-react';
import { useTheme } from "../components/ThemeContext";
import MedicalParticles from "../components/MedicalParticles";

// --- Helper Components & Hooks ---

const TiltCard = ({ children, className, ...props }) => (
  <div className={`transform transition-transform duration-300 hover:rotate-2 hover:scale-105 ${className}`} {...props}>
    {children}
  </div>
);

const useScript = (src) => {
  const [status, setStatus] = useState(src ? "loading" : "idle");
  useEffect(() => {
    if (!src) { setStatus("idle"); return; }
    let script = document.querySelector(`script[src="${src}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.setAttribute("data-status", "loading");
      document.body.appendChild(script);
      const setAttributeFromEvent = (event) => {
        script.setAttribute("data-status", event.type === "load" ? "ready" : "error");
      };
      script.addEventListener("load", setAttributeFromEvent);
      script.addEventListener("error", setAttributeFromEvent);
    } else {
      setStatus(script.getAttribute("data-status"));
    }
    const setStateFromEvent = (event) => {
      setStatus(event.type === "load" ? "ready" : "error");
    };
    script.addEventListener("load", setStateFromEvent);
    script.addEventListener("error", setStateFromEvent);
    return () => {
      if (script) {
        script.removeEventListener("load", setStateFromEvent);
        script.removeEventListener("error", setStateFromEvent);
      }
    };
  }, [src]);
  return status;
};

const MapComponent = ({ location, zoom = 15 }) => {
  const mapRef = useRef(null);
  const leafletStatus = useScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');

  useEffect(() => {
    if (leafletStatus !== 'ready' || !location || !mapRef.current || !window.L) return;
    const map = window.L.map(mapRef.current).setView([location.lat, location.lng], zoom);
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    window.L.marker([location.lat, location.lng]).addTo(map);
    setTimeout(() => map.invalidateSize(), 100);
    return () => {
      map.remove();
    };
  }, [leafletStatus, location, zoom]);

  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const leafletCss = document.createElement('link');
      leafletCss.id = 'leaflet-css';
      leafletCss.rel = 'stylesheet';
      leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(leafletCss);
    }
  }, []);

  if (leafletStatus === 'loading') return <div className="flex items-center justify-center h-full bg-gray-200 rounded-lg"><p>Loading map...</p></div>;
  if (leafletStatus === 'error') return <div className="flex items-center justify-center h-full bg-red-100 text-red-700 rounded-lg"><p>Error loading map.</p></div>;
  return <div ref={mapRef} style={{ height: '250px', width: '100%', borderRadius: '12px', zIndex: 0 }}></div>;
};

// --- Main Prescriptions Component ---

export default function Prescriptions() {
  const { theme } = useTheme();

  const hospitalData = {
    'Black Lion Hospital': {
      name: 'Black Lion Specialized Hospital',
      address: 'Tikur Anbessa, Addis Ababa, Ethiopia',
      contact: '+251 11 551 1211',
      website: 'https://www.aau.edu.et/chs/black-lion-specialized-hospital/',
      location: { lat: 9.0223, lng: 38.7486 }
    },
  };

  const [prescriptions, setPrescriptions] = useState(() => {
    try {
      const saved = localStorage.getItem('pharmacyPrescriptionsV4');
      return saved ? JSON.parse(saved) : [
        { id: "RX-001", patientName: "Jane Doe", birthDate: "1993-05-15", patientContact: "555-1234", dateIssued: "2025-09-11", status: "Pending", notes: "Patient has mild headache.", medicines: [{ name: "Paracetamol", quantity: 2, dosage: "1 pill twice a day" }, { name: "Ibuprofen", quantity: 1, dosage: "1 pill after meals" }], source: 'pharmacist' },
        { id: "RX-002", patientName: "John Smith", birthDate: "1985-10-20", patientContact: "555-5678", dateIssued: "2025-09-12", status: "Processed", notes: "Follow up after one week.", medicines: [{ name: "Amoxicillin", quantity: 1, dosage: "1 capsule every 8 hours" }], source: 'pharmacist' },
        { id: "RX-HOS-003", patientName: "Abebe Bikila", birthDate: "1978-02-28", patientContact: "555-9900", dateIssued: "2025-09-10", status: "Pending", notes: "Received via secure mail.", medicines: [{ name: "Lisinopril", quantity: 1, dosage: "10mg once daily" }], source: 'hospital', doctorName: 'Dr. Eleni', hospitalName: 'Black Lion Hospital', conversation: [{ sender: 'Dr. Eleni', text: 'Please confirm you have received this prescription for Abebe Bikila.', timestamp: '11:15 AM' }, { sender: 'You', text: 'Received. We are processing it now.', timestamp: '11:17 AM' }] },
      ];
    } catch (error) {
      console.error("Failed to parse prescriptions from localStorage", error);
      return [];
    }
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [hospitalModalOpen, setHospitalModalOpen] = useState(false);
  const [messagingModalOpen, setMessagingModalOpen] = useState(false);
  const [activeConversation, setActiveConversation] = useState(null);
  const [viewingHospital, setViewingHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    localStorage.setItem('pharmacyPrescriptionsV4', JSON.stringify(prescriptions));
  }, [prescriptions]);

  const calculateAge = (birthDate) => {
    if (!birthDate) return 0;
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age >= 0 ? age : 0;
  };

  const getStatusStyles = (status) => {
    switch (status) {
      case "Processed": return { border: "border-green-500", tag: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" };
      case "Pending": return { border: "border-yellow-500", tag: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300" };
      default: return { border: theme === 'dark' ? "border-gray-700" : "border-gray-300", tag: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300" };
    }
  };

  const handleAdd = () => setModalOpen(true);

  const handleViewHospital = (hospitalName) => {
    const hospital = hospitalData[hospitalName];
    if (hospital) {
      setViewingHospital(hospital);
      setHospitalModalOpen(true);
    }
  };

  const handleOpenMessaging = (prescription) => {
    setActiveConversation(prescription);
    setMessagingModalOpen(true);
  };

  const handleSendMessage = (prescriptionId, text) => {
    const newMessage = {
      sender: 'You',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    const updatedPrescriptions = prescriptions.map(p => {
      if (p.id === prescriptionId) {
        const conversation = p.conversation ? [...p.conversation, newMessage] : [newMessage];
        return { ...p, conversation };
      }
      return p;
    });
    setPrescriptions(updatedPrescriptions);
    setActiveConversation(prev => ({ ...prev, conversation: [...(prev.conversation || []), newMessage] }));
  };

  const filteredPrescriptions = useMemo(() => {
    return prescriptions.filter(p =>
      (filterStatus === 'all' || p.status === filterStatus) &&
      (p.patientName.toLowerCase().includes(searchTerm.toLowerCase()) || p.id.toLowerCase().includes(searchTerm.toLowerCase()))
    ).map(p => ({ ...p, patientAge: calculateAge(p.birthDate) }));
  }, [prescriptions, searchTerm, filterStatus]);

  const PrescriptionFormModal = ({ isOpen, onClose, onSave }) => {
    const [formData, setFormData] = useState({ patientName: '', birthDate: '', patientContact: '', notes: '', medicines: [{ name: '', quantity: 1, dosage: '' }] });
    useEffect(() => {
      setFormData({ patientName: '', birthDate: '', patientContact: '', notes: '', medicines: [{ name: '', quantity: 1, dosage: '' }] });
    }, [isOpen]);
    const handleChange = (e, index) => {
      const { name, value } = e.target;
      if (name.startsWith('med-')) {
        const field = name.split('-')[1];
        const newMedicines = [...formData.medicines];
        newMedicines[index][field] = value;
        setFormData(prev => ({ ...prev, medicines: newMedicines }));
      } else {
        setFormData(prev => ({ ...prev, [name]: value }));
      }
    };
    const addMedicine = () => setFormData(prev => ({ ...prev, medicines: [...prev.medicines, { name: '', quantity: 1, dosage: '' }] }));
    const removeMedicine = (index) => {
      if (formData.medicines.length <= 1) return;
      setFormData(prev => ({ ...prev, medicines: prev.medicines.filter((_, i) => i !== index) }));
    };
    const handleSubmit = (e) => {
      e.preventDefault();
      const cleanedMedicines = formData.medicines.filter(m => m.name.trim() !== '');
      if (!formData.patientName || !formData.birthDate || cleanedMedicines.length === 0) {
        alert("Patient Name, Birth Date, and at least one medicine are required.");
        return;
      }
      onSave({ ...formData, medicines: cleanedMedicines });
      onClose();
    };
    if (!isOpen) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <div className={`relative w-full max-w-2xl max-h-[90vh] animate-modal-pop rounded-xl shadow-2xl ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'}`}>
          <div className="flex items-center justify-between border-b px-6 py-4">
            <h3 className="font-semibold text-lg">Add Prescription</h3>
            <button onClick={onClose} className="p-1 rounded-full text-xl h-8 w-8 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700">✕</button>
          </div>
          <form onSubmit={handleSubmit} className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 120px)' }}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className="text-sm">Patient Name*</label><input required name="patientName" value={formData.patientName} onChange={handleChange} className="w-full mt-1 p-2 rounded-md border" /></div>
              <div><label className="text-sm">Birth Date*</label><input required type="date" name="birthDate" value={formData.birthDate} onChange={handleChange} max={new Date().toISOString().split("T")[0]} className="w-full mt-1 p-2 rounded-md border" /></div>
              <div className="sm:col-span-2"><label className="text-sm">Patient Contact</label><input name="patientContact" value={formData.patientContact} onChange={handleChange} className="w-full mt-1 p-2 rounded-md border" /></div>
              <div className="sm:col-span-2"><label className="text-sm">Notes</label><textarea name="notes" value={formData.notes} onChange={handleChange} rows="3" className="w-full mt-1 p-2 rounded-md border"></textarea></div>
            </div>
            <h4 className="font-semibold mt-6 mb-2">Medicines</h4>
            {formData.medicines.map((med, index) => (
              <div key={index} className="grid grid-cols-8 gap-2 mb-2 items-center">
                <input name={`med-name`} value={med.name} onChange={(e) => handleChange(e, index)} placeholder="Medicine Name" className="col-span-3 p-2 rounded-md border" />
                <input type="number" name={`med-quantity`} value={med.quantity} onChange={(e) => handleChange(e, index)} min="1" placeholder="Qty" className="col-span-1 p-2 rounded-md border" />
                <input name={`med-dosage`} value={med.dosage} onChange={(e) => handleChange(e, index)} placeholder="Dosage" className="col-span-3 p-2 rounded-md border" />
                <button type="button" onClick={() => removeMedicine(index)} disabled={formData.medicines.length <= 1} className="col-span-1 h-10 w-10 text-red-500 disabled:text-gray-400 rounded-full hover:bg-red-100 disabled:hover:bg-transparent flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                </button>
              </div>
            ))}
            <button type="button" onClick={addMedicine} className="mt-2 text-sm text-indigo-600 hover:underline">+ Add another medicine</button>
            <div className="flex justify-end gap-2 mt-6 border-t pt-4">
              <button type="button" onClick={onClose} className="px-4 py-2 rounded-md border">Cancel</button>
              <button type="submit" className="px-4 py-2 rounded-md bg-indigo-600 text-white">Save Prescription</button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const HospitalProfileModal = ({ isOpen, onClose, hospital }) => {
    if (!isOpen || !hospital) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <div className={`relative w-full max-w-lg animate-modal-pop rounded-xl shadow-2xl ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'}`}>
          <div className="flex items-center justify-between border-b px-6 py-4">
            <h3 className="font-semibold text-lg">Hospital Profile</h3>
            <button onClick={onClose} className="p-1 rounded-full text-xl h-8 w-8 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700">✕</button>
          </div>
          <div className="p-6 space-y-4">
            <h4 className="text-xl font-bold">{hospital.name}</h4>
            <p><strong>Address:</strong> {hospital.address}</p>
            <p><strong>Contact:</strong> {hospital.contact}</p>
            <p><strong>Website:</strong> <a href={hospital.website} target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline">{hospital.website}</a></p>
            <div>
              <h5 className="font-semibold mb-2">Location</h5>
              <MapComponent location={hospital.location} />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-2 p-4 border-t">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-md border">Close</button>
          </div>
        </div>
      </div>
    );
  };

  const MessagingModal = ({ isOpen, onClose, prescription, onSendMessage }) => {
    const [text, setText] = useState('');
    const messagesEndRef = useRef(null);
    useEffect(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [prescription?.conversation]);

    if (!isOpen || !prescription) return null;

    const handleSubmit = (e) => {
      e.preventDefault();
      if (!text.trim()) return;
      onSendMessage(prescription.id, text);
      setText('');
    };

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <div className={`relative w-full max-w-lg h-[70vh] flex flex-col animate-modal-pop rounded-xl shadow-2xl ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'}`}>
          <div className="flex-shrink-0 flex items-center justify-between border-b px-6 py-4">
            <div>
              <h3 className="font-semibold text-lg">Chat re: {prescription.id}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">With {prescription.doctorName} at {prescription.hospitalName}</p>
            </div>
            <button onClick={onClose} className="p-1 rounded-full text-xl h-8 w-8 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700">✕</button>
          </div>
          <div className="flex-grow p-6 overflow-y-auto space-y-4">
            {(prescription.conversation || []).map((msg, i) => (
              <div key={i} className={`flex items-end gap-2 ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-md p-3 rounded-2xl ${msg.sender === 'You' ? 'bg-indigo-600 text-white rounded-br-none' : `${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'} rounded-bl-none`}`}>
                  <p>{msg.text}</p>
                  <p className={`text-xs mt-1 ${msg.sender === 'You' ? 'text-indigo-200' : 'text-gray-500 dark:text-gray-400'}`}>{msg.timestamp}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          <form onSubmit={handleSubmit} className="flex-shrink-0 p-4 border-t flex items-center gap-3">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type a message..."
              className={`w-full p-2 rounded-full border ${theme === 'dark' ? 'bg-gray-700 text-white border-gray-600' : 'bg-white text-black border-gray-300'}`}
            />
            <button type="submit" className="bg-indigo-600 text-white rounded-full p-3 hover:bg-indigo-500 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </form>
        </div>
      </div>
    );
  };

  const handleSave = (data) => {
    const newPrescription = { ...data, id: `RX-${Date.now()}`, patientAge: calculateAge(data.birthDate), status: 'Pending', dateIssued: new Date().toISOString().split("T")[0], source: 'pharmacist' };
    setPrescriptions([newPrescription, ...prescriptions]);
  };

  return (
    <div className={`relative flex flex-col h-screen p-6 ${theme === "dark" ? "bg-gray-900" : "bg-gray-50"}`}>
      <MedicalParticles />
      <div className="relative z-10 flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">Prescriptions</h1>
        <button onClick={handleAdd} className="rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:scale-105 transition">Add Prescription</button>
      </div>
      <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <input
          type="text"
          placeholder="Search by ID or Patient Name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={`w-full sm:w-1/2 rounded-md border px-3 py-2 text-sm ${theme === 'dark' ? 'bg-gray-700 text-white border-gray-600' : 'bg-white text-black border-gray-300'}`}
        />
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className={`w-full sm:w-auto rounded-md border px-3 py-2 text-sm ${theme === 'dark' ? 'bg-gray-700 text-white border-gray-600' : 'bg-white text-black border-gray-300'}`}
        >
          <option value="all">All Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Processed">Processed</option>
        </select>
      </div>
      <div className="relative z-10 flex-1 overflow-y-auto pr-2">
        <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2 auto-rows-min">
          {filteredPrescriptions.map((p) => {
            const { border, tag } = getStatusStyles(p.status);
            const isHospitalRx = p.source === 'hospital';
            return (
              <TiltCard
                key={p.id}
                className={`relative rounded-xl p-6 shadow-lg border-2 bg-gradient-to-br ${
                  theme === 'dark'
                    ? 'from-gray-800 to-gray-900 border-gray-700 text-white'
                    : 'from-white to-gray-50 border-gray-200 text-black'
                } transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 hover:ring-2 hover:ring-indigo-300 dark:hover:ring-indigo-500 animate-fade-in delay-[${p.id.split('-').pop() * 100}ms]`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <FileText className="w-6 h-6 text-indigo-600 dark:text-indigo-400 animate-pulse" />
                    <div>
                      <h2 className="text-lg font-semibold tracking-tight">{p.patientName} ({p.patientAge})</h2>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{p.id} &bull; {p.dateIssued}</p>
                      {isHospitalRx && (
                        <p className="text-xs text-indigo-400 mt-1 font-semibold cursor-pointer hover:underline" onClick={(e) => { e.stopPropagation(); handleViewHospital(p.hospitalName); }}>
                          From {p.hospitalName} (Dr. {p.doctorName})
                        </p>
                      )}
                    </div>
                  </div>
                  <span className={`px-2.5 py-0.5 text-xs rounded-full font-semibold ${tag}`}>{p.status}</span>
                </div>
                <div className="text-sm space-y-3 mb-4">
                  {p.medicines.map((m, i) => (
                    <div key={i} className="flex justify-between">
                      <span><strong>{m.name}</strong> ({m.quantity})</span>
                      <span className="text-gray-600 dark:text-gray-300">{m.dosage}</span>
                    </div>
                  ))}
                </div>
                {p.notes && (
                  <p className="text-sm italic border-l-4 pl-3 py-1 border-indigo-400 dark:border-indigo-600 bg-indigo-50 dark:bg-indigo-900/30">"{p.notes}"</p>
                )}
                <div className="flex gap-2 mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <button
                    onClick={() => setPrescriptions(prescriptions.map(item => item.id === p.id ? { ...item, status: 'Processed' } : item))}
                    className={`flex-1 rounded-md px-3 py-2 text-sm ${theme === 'dark' ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-green-500 hover:bg-green-600 text-white'} disabled:bg-gray-400 disabled:hover:bg-gray-400`}
                    disabled={p.status === 'Processed'}
                  >
                    Mark as Processed
                  </button>
                  {isHospitalRx && (
                    <button
                      onClick={() => handleOpenMessaging(p)}
                      className={`flex-1 rounded-md px-3 py-2 text-sm ${theme === 'dark' ? 'bg-purple-600 hover:bg-purple-500 text-white' : 'bg-purple-500 hover:bg-purple-600 text-white'}`}
                    >
                      Message Doctor
                    </button>
                  )}
                </div>
              </TiltCard>
            );
          })}
        </div>
      </div>
      <PrescriptionFormModal isOpen={modalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} />
      <HospitalProfileModal isOpen={hospitalModalOpen} onClose={() => setHospitalModalOpen(false)} hospital={viewingHospital} />
      <MessagingModal isOpen={messagingModalOpen} onClose={() => setMessagingModalOpen(false)} prescription={activeConversation} onSendMessage={handleSendMessage} />
    </div>
  );
}