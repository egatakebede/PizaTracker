import React, { useState, useEffect } from "react";
import { useTheme } from "../components/ThemeContext";

// --- Helper Components & Hooks ---
const MedicalParticles = () => (
  <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1, opacity: 0.1 }} />
);

const TiltCard = ({ children, className, ...props }) => (
    <div className={className} {...props}>{children}</div>
);

const useScript = (src) => {
    const [status, setStatus] = useState(src ? "loading" : "idle");
    useEffect(() => {
        if (!src) { setStatus("idle"); return; }
        let script = document.querySelector(`script[src="${src}"]`);
        if (!script) {
            script = document.createElement("script");
            script.src = src;
            script.async = true;
            script.setAttribute("data-status", "loading");
            document.body.appendChild(script);
            const setAttributeFromEvent = (event) => {
                script.setAttribute("data-status", event.type === "load" ? "ready" : "error");
            };
            script.addEventListener("load", setAttributeFromEvent);
            script.addEventListener("error", setAttributeFromEvent);
        } else {
            setStatus(script.getAttribute("data-status"));
        }
        const setStateFromEvent = (event) => {
            setStatus(event.type === "load" ? "ready" : "error");
        };
        script.addEventListener("load", setStateFromEvent);
        script.addEventListener("error", setStateFromEvent);
        return () => {
            if (script) {
                script.removeEventListener("load", setStateFromEvent);
                script.removeEventListener("error", setStateFromEvent);
            }
        };
    }, [src]);
    return status;
};

// --- Main Dashboard Component ---
function DashboardComponent() {
  const { theme } = useTheme();
  const rechartsStatus = useScript('https://cdnjs.cloudflare.com/ajax/libs/recharts/2.12.7/recharts.min.js');
  
  // Mock useNavigate
  const navigate = (path) => console.log(`Navigating to ${path}`);

  const [stats, setStats] = useState({ salesToday: 0, pendingOrders: 0, lowStockItems: 0 });
  const [recentActivity, setRecentActivity] = useState([]);
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    const mockOrders = [
        { status: 'Pending', total: 120.50, customer: 'Jane Doe' },
        { status: 'Completed', total: 85.00, customer: 'John Smith' },
        { status: 'Pending', total: 250.00, customer: 'Abebe Bikila' },
    ];
    const mockInventory = [
        { name: 'Paracetamol', stock: 150, lowStockThreshold: 100 },
        { name: 'Ibuprofen', stock: 45, lowStockThreshold: 50 },
        { name: 'Amoxicillin', stock: 20, lowStockThreshold: 30 },
    ];
     const mockPrescriptions = [
        { id: 'RX-HOS-003', source: 'Black Lion Hospital', patient: 'Abebe Bikila' }
     ];

    const salesToday = mockOrders.reduce((acc, order) => acc + order.total, 0);
    const pendingOrders = mockOrders.filter(o => o.status === 'Pending').length;
    const lowStockItems = mockInventory.filter(i => i.stock < i.lowStockThreshold).length;

    setStats({ salesToday, pendingOrders, lowStockItems });
    
    setRecentActivity([
        { description: `New order from ${mockOrders[0].customer}`, time: '5m ago' },
        { description: `New Rx from ${mockPrescriptions[0].source}`, time: '1h ago' },
        { description: `${mockInventory[1].name} is low on stock`, time: '3h ago' },
    ]);
    
    setSalesData([
        { name: 'Mon', Sales: 400 }, { name: 'Tue', Sales: 300 }, { name: 'Wed', Sales: 500 },
        { name: 'Thu', Sales: 475 }, { name: 'Fri', Sales: 620 }, { name: 'Sat', Sales: 800 },
        { name: 'Sun', Sales: 750 },
    ]);

  }, []);

  const statCards = [
    { label: "Total Sales Today", value: `$${stats.salesToday.toFixed(2)}`, path: '/reports' },
    { label: "Pending Orders", value: stats.pendingOrders, path: '/orders' },
    { label: "Low Stock Items", value: stats.lowStockItems, path: '/inventory' },
  ];

  return (
    <div
      className={`relative min-h-screen p-6 overflow-y-auto ${
        theme === "light"
          ? "bg-gradient-to-br from-green-50 to-blue-50 text-gray-800"
          : "bg-gradient-to-br from-slate-900 to-slate-800 text-gray-200"
      }`}
    >
      <MedicalParticles variant="dashboard" />
      <div className="relative z-10 mb-6">
        <h1 className="text-3xl font-bold text-green-600 dark:text-green-400">Pharmacy Dashboard</h1>
      </div>
      
      {/* Welcome Banner */}
      <TiltCard className="rounded-2xl shadow-xl overflow-hidden mb-6">
        <div className="p-12 text-center" style={{ backgroundImage: "linear-gradient(270deg, #16A34A, #3B82F6, #16A34A)", backgroundSize: "200% 200%", animation: "gradient-animation 6s ease infinite" }}>
          <style>{`@keyframes gradient-animation { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }`}</style>
          <div className="text-4xl font-extrabold text-white drop-shadow-lg">Welcome, Admin!</div>
          <div className="text-lg mt-3 text-white/90">Here is a summary of today's activity.</div>
        </div>
      </TiltCard>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
        {statCards.map((s, i) => (
          <TiltCard
            key={i}
            onClick={() => navigate(s.path)}
            className={`p-5 rounded-2xl shadow-lg transition hover:shadow-2xl hover:-translate-y-1 cursor-pointer ${ theme === "light" ? "bg-white" : "bg-slate-800" }`}
          >
            <div className="text-sm text-gray-500 dark:text-slate-400">{s.label}</div>
            <div className={`mt-2 text-3xl font-bold ${s.label === 'Low Stock Items' && s.value > 0 ? 'text-red-500' : ''}`}>{s.value}</div>
          </TiltCard>
        ))}
      </div>

      {/* Main Content Area: Chart and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Chart */}
        <div className={`lg:col-span-2 p-5 rounded-xl shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}>
             <h3 className="font-semibold mb-4">Weekly Sales Trend</h3>
             {rechartsStatus === 'ready' ? (
                <div style={{ width: '100%', height: 300 }}>
                    <window.Recharts.ResponsiveContainer>
                        <window.Recharts.BarChart data={salesData}>
                            <window.Recharts.CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#334155' : '#E2E8F0'} />
                            <window.Recharts.XAxis dataKey="name" stroke={theme === 'dark' ? '#94A3B8' : '#4A5568'} />
                            <window.Recharts.YAxis stroke={theme === 'dark' ? '#94A3B8' : '#4A5568'} />
                            <window.Recharts.Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? '#1E293B' : '#FFFFFF' }} />
                            <window.Recharts.Bar dataKey="Sales" fill="#3B82F6" />
                        </window.Recharts.BarChart>
                    </window.Recharts.ResponsiveContainer>
                 </div>
             ) : <p>Loading chart...</p>}
        </div>

        {/* Recent Activity */}
        <div className={`p-5 rounded-xl shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}>
            <h3 className="font-semibold mb-4">Recent Activity</h3>
            <ul className="space-y-4">
                {recentActivity.map((activity, i) => (
                    <li key={i} className="border-l-4 border-indigo-500 pl-3">
                        <p className="font-semibold text-sm">{activity.description}</p>
                        <p className="text-xs text-gray-500 dark:text-slate-400">{activity.time}</p>
                    </li>
                ))}
            </ul>
        </div>
      </div>

    </div>
  );
}

// --- Main App Component ---
export default function Dashboard() {
    return <DashboardComponent />;
}