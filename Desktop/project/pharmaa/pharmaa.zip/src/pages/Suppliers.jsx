import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useTheme } from '../components/ThemeContext'; // <-- CORRECT: Use the global theme context
import MedicalParticles from "../components/MedicalParticles";
import TiltCard from "./TiltCard";

// --- Helper Components & Hooks ---
const useScript = (src) => {
    const [status, setStatus] = useState(src ? "loading" : "idle");
    useEffect(() => {
        if (!src) { setStatus("idle"); return; }
        let script = document.querySelector(`script[src="${src}"]`);
        if (!script) {
            script = document.createElement("script");
            script.src = src;
            script.async = true;
            script.setAttribute("data-status", "loading");
            document.body.appendChild(script);
            const setAttributeFromEvent = (event) => {
                script.setAttribute("data-status", event.type === "load" ? "ready" : "error");
            };
            script.addEventListener("load", setAttributeFromEvent);
            script.addEventListener("error", setAttributeFromEvent);
        } else {
            setStatus(script.getAttribute("data-status"));
        }
        const setStateFromEvent = (event) => {
            setStatus(event.type === "load" ? "ready" : "error");
        };
        script.addEventListener("load", setStateFromEvent);
        script.addEventListener("error", setStateFromEvent);
        return () => {
            if (script) {
                script.removeEventListener("load", setStateFromEvent);
                script.removeEventListener("error", setStateFromEvent);
            }
        };
    }, [src]);
    return status;
};

const MapComponent = ({ location, zoom = 15 }) => {
    const mapRef = useRef(null);
    const leafletStatus = useScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');

    useEffect(() => {
        if (leafletStatus !== 'ready' || !location || !mapRef.current || !window.L) return;
        
        const map = window.L.map(mapRef.current).setView([location.lat, location.lng], zoom);
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        window.L.marker([location.lat, location.lng]).addTo(map);

        setTimeout(() => map.invalidateSize(), 100);

        return () => map.remove();
    }, [leafletStatus, location, zoom]);
    
    useEffect(() => {
        if (!document.getElementById('leaflet-css')) {
            const leafletCss = document.createElement('link');
            leafletCss.id = 'leaflet-css';
            leafletCss.rel = 'stylesheet';
            leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
            document.head.appendChild(leafletCss);
        }
    }, []);

    if (leafletStatus === 'loading') return <div className="flex items-center justify-center h-full bg-gray-200 rounded-lg"><p>Loading map...</p></div>;
    if (leafletStatus === 'error') return <div className="flex items-center justify-center h-full bg-red-100 text-red-700 rounded-lg"><p>Error loading map.</p></div>;
    
    return <div ref={mapRef} style={{ height: '200px', width: '100%', borderRadius: '12px', zIndex: 0 }}></div>;
};

// --- Main Suppliers Component ---

function SuppliersComponent() {
    const { theme } = useTheme();

    const allPurchaseOrders = [
        { id: 'PO-001', supplierId: 1, date: '2025-07-20', total: 1250.00, status: 'Received' },
        { id: 'PO-002', supplierId: 2, date: '2025-08-05', total: 3400.50, status: 'Shipped' },
        { id: 'PO-003', supplierId: 1, date: '2025-08-15', total: 850.75, status: 'Placed' },
    ];
    
    const allProducts = [
        { id: 'PROD-01', supplierId: 1, name: 'Paracetamol 500mg', cost: 1.50, stock: 150 },
        { id: 'PROD-02', supplierId: 1, name: 'Ibuprofen 200mg', cost: 2.10, stock: 80 },
        { id: 'PROD-03', supplierId: 2, name: 'Amoxicillin 250mg', cost: 3.50, stock: 40 },
    ];

    const [suppliers, setSuppliers] = useState(() => {
        try {
            const saved = localStorage.getItem('pharmacySuppliers');
            return saved ? JSON.parse(saved) : [
                { id: 1, name: "PharmaSource Inc.", category: "General Medications", status: "Active", contactPerson: "John Doe", avatarUrl: "https://placehold.co/100x100/A78BFA/FFFFFF?text=PI", location: { address: "123 Pharma Lane, Addis Ababa", lat: 9.021, lng: 38.752 }, conversation: [{ sender: 'John Doe', text: 'Hi, confirming your last PO-003.', timestamp: '11:00 AM' }] },
                { id: 2, name: "MediEquip Solutions", category: "Medical Equipment", status: "Active", contactPerson: "Jane Smith", avatarUrl: "https://placehold.co/100x100/F472B6/FFFFFF?text=MS", location: { address: "456 Health St, Addis Ababa", lat: 9.015, lng: 38.765 }, conversation: [] },
            ];
        } catch (error) {
            console.error("Failed to parse suppliers from localStorage", error);
            return [];
        }
    });

    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [viewingSupplier, setViewingSupplier] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [sortKey, setSortKey] = useState("name");

    useEffect(() => {
        localStorage.setItem('pharmacySuppliers', JSON.stringify(suppliers));
    }, [suppliers]);

    const handleViewProfile = (supplier) => {
        setViewingSupplier(supplier);
        setIsProfileModalOpen(true);
    };

    const handleAddSupplier = (newSupplierData) => {
        const newSupplier = {
            id: Date.now(),
            ...newSupplierData,
            avatarUrl: `https://placehold.co/100x100/E2E8F0/4A5568?text=${newSupplierData.name.substring(0,2).toUpperCase()}`,
            conversation: []
        };
        setSuppliers(prev => [newSupplier, ...prev]);
        setIsAddModalOpen(false);
    };

    const handleSendMessage = (supplierId, text) => {
        const newMessage = {
            sender: 'You', text, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        const updatedSuppliers = suppliers.map(s => {
            if (s.id === supplierId) {
                const conversation = s.conversation ? [...s.conversation, newMessage] : [newMessage];
                return { ...s, conversation };
            }
            return s;
        });
        setSuppliers(updatedSuppliers);
        setViewingSupplier(prev => ({...prev, conversation: [...(prev.conversation || []), newMessage]}));
    };

    const sortedAndFilteredSuppliers = useMemo(() => {
        return suppliers
            .filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()))
            .sort((a, b) => {
                if (a[sortKey] < b[sortKey]) return -1;
                if (a[sortKey] > b[sortKey]) return 1;
                return 0;
            });
    }, [suppliers, searchTerm, sortKey]);
    
    // --- MODAL COMPONENTS ---

    const AddSupplierForm = ({ isOpen, onClose, onSave }) => {
        const [formData, setFormData] = useState({ name: '', category: '', contactPerson: '', status: 'Active', location: { address: '', lat: '', lng: '' }});

        const handleChange = (e) => {
            const { name, value } = e.target;
            if (name.includes('.')) {
                const [parent, child] = name.split('.');
                setFormData(prev => ({ ...prev, [parent]: { ...prev[parent], [child]: value } }));
            } else {
                setFormData(prev => ({ ...prev, [name]: value }));
            }
        };

        const handleSubmit = (e) => {
            e.preventDefault();
            onSave(formData);
        };
        
        if (!isOpen) return null;

        return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
                <div className={`relative w-full max-w-lg animate-modal-pop rounded-xl shadow-2xl ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'}`}>
                    <div className="flex items-center justify-between border-b px-6 py-4 dark:border-gray-700"><h3 className="font-semibold text-lg">Add New Supplier</h3><button onClick={onClose} className="p-1 rounded-full text-xl h-8 w-8 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700">✕</button></div>
                    <form onSubmit={handleSubmit} className="p-6 overflow-y-auto" style={{maxHeight: 'calc(90vh - 120px)'}}>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="sm:col-span-2"><label className="text-sm">Supplier Name*</label><input required name="name" value={formData.name} onChange={handleChange} className={`w-full mt-1 p-2 rounded-md border ${theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'}`}/></div>
                            <div><label className="text-sm">Category</label><input name="category" value={formData.category} onChange={handleChange} className={`w-full mt-1 p-2 rounded-md border ${theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'}`}/></div>
                            <div><label className="text-sm">Contact Person</label><input name="contactPerson" value={formData.contactPerson} onChange={handleChange} className={`w-full mt-1 p-2 rounded-md border ${theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'}`}/></div>
                            <div className="sm:col-span-2"><label className="text-sm">Address</label><input name="location.address" value={formData.location.address} onChange={handleChange} className={`w-full mt-1 p-2 rounded-md border ${theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'}`}/></div>
                        </div>
                         <div className="flex justify-end gap-2 mt-6 border-t pt-4 dark:border-gray-700">
                            <button type="button" onClick={onClose} className="px-4 py-2 rounded-md border dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700">Cancel</button>
                            <button type="submit" className="px-4 py-2 rounded-md bg-indigo-600 text-white hover:bg-indigo-500">Save Supplier</button>
                        </div>
                    </form>
                </div>
            </div>
        )
    };

    const SupplierProfileModal = ({ isOpen, onClose, supplier, onSendMessage }) => {
        const [activeTab, setActiveTab] = useState('profile');
        const [newMessage, setNewMessage] = useState('');
        const messagesEndRef = useRef(null);
        
        const supplierOrders = useMemo(() => supplier ? allPurchaseOrders.filter(o => o.supplierId === supplier.id) : [], [supplier]);
        const supplierProducts = useMemo(() => supplier ? allProducts.filter(p => p.supplierId === supplier.id) : [], [supplier]);

        useEffect(() => { if (isOpen) setActiveTab('profile'); }, [isOpen]);
        useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [supplier?.conversation]);

        if (!isOpen || !supplier) return null;

        const getStatusColor = (status) => {
            switch (status) {
              case "Received": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
              case "Placed": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
              case "Shipped": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
              default: return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300";
            }
        };

        const handleMessageSubmit = (e) => {
            e.preventDefault();
            if (!newMessage.trim()) return;
            onSendMessage(supplier.id, newMessage);
            setNewMessage('');
        };

        return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
                <div className={`relative w-full max-w-2xl max-h-[90vh] flex flex-col animate-modal-pop rounded-xl shadow-2xl ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-black'}`}>
                    <div className="flex-shrink-0 flex items-center justify-between border-b px-6 py-4 dark:border-gray-700"><h3 className="font-semibold text-lg">Supplier Profile</h3><button onClick={onClose} className="p-1 rounded-full text-xl h-8 w-8 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700">✕</button></div>
                    <div className="flex-shrink-0 p-6 flex items-center gap-4"><img src={supplier.avatarUrl} alt={supplier.name} className="w-24 h-24 rounded-full" /><div><h4 className="text-2xl font-bold">{supplier.name}</h4><p className="text-sm text-gray-500 dark:text-gray-400">{supplier.category}</p><p className="text-sm text-gray-500 dark:text-gray-400">Contact: {supplier.contactPerson}</p></div></div>
                    <nav className="flex-shrink-0 border-b border-t px-6 dark:border-gray-700">
                        <button onClick={() => setActiveTab('profile')} className={`py-3 px-4 text-sm font-semibold border-b-2 ${activeTab === 'profile' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}`}>Profile</button>
                        <button onClick={() => setActiveTab('products')} className={`py-3 px-4 text-sm font-semibold border-b-2 ${activeTab === 'products' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}`}>Product Catalog</button>
                        <button onClick={() => setActiveTab('orders')} className={`py-3 px-4 text-sm font-semibold border-b-2 ${activeTab === 'orders' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}`}>Order History</button>
                        <button onClick={() => setActiveTab('messaging')} className={`py-3 px-4 text-sm font-semibold border-b-2 ${activeTab === 'messaging' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}`}>Messaging</button>
                    </nav>
                    <div className="flex-grow p-6 overflow-y-auto">
                       {activeTab === 'profile' && ( <div className="space-y-4"><div><h5 className="font-semibold mb-2">Location</h5><p className="text-sm mb-2 text-gray-500 dark:text-gray-400">{supplier.location.address}</p><MapComponent location={supplier.location} /></div></div> )}
                       {activeTab === 'products' && ( <ul className="space-y-3">{supplierProducts.map(prod => ( <li key={prod.id} className="p-3 rounded-lg border flex justify-between items-center dark:border-gray-700"><div><p className="font-semibold">{prod.name}</p><p className="text-sm text-gray-500 dark:text-gray-400">Cost: ${prod.cost.toFixed(2)}</p></div><p className="font-bold">{prod.stock} in stock</p></li> ))}{supplierProducts.length === 0 && <p className="text-gray-500 dark:text-gray-400 text-center">No products found.</p>}</ul> )}
                       {activeTab === 'orders' && ( <ul className="space-y-3">{supplierOrders.map(order => ( <li key={order.id} className="p-3 rounded-lg border flex justify-between items-center dark:border-gray-700"><div><p className="font-semibold">{order.id}</p><p className="text-sm text-gray-500 dark:text-gray-400">{order.date}</p></div><div className="text-right"><p className="font-bold">${order.total.toFixed(2)}</p><span className={`px-2 py-0.5 text-xs rounded-full font-semibold ${getStatusColor(order.status)}`}>{order.status}</span></div></li> ))}{supplierOrders.length === 0 && <p className="text-gray-500 dark:text-gray-400 text-center">No purchase order history found.</p>}</ul> )}
                       {activeTab === 'messaging' && ( <div className="h-full flex flex-col"><div className="flex-grow space-y-4 overflow-y-auto pr-2">{(supplier.conversation || []).map((msg, i) => ( <div key={i} className={`flex items-end gap-2 ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-md p-3 rounded-2xl ${msg.sender === 'You' ? 'bg-indigo-600 text-white rounded-br-none' : `bg-gray-200 dark:bg-gray-700 rounded-bl-none`}`}><p>{msg.text}</p><p className={`text-xs mt-1 ${msg.sender === 'You' ? 'text-indigo-200' : 'text-gray-500 dark:text-gray-400'}`}>{msg.timestamp}</p></div></div> ))}<div ref={messagesEndRef} /></div><form onSubmit={handleMessageSubmit} className="flex-shrink-0 pt-4 flex items-center gap-3"><input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type a message..." className={`w-full p-2 rounded-full border bg-transparent dark:border-gray-600`} /><button type="submit" className="bg-indigo-600 text-white rounded-full p-3 hover:bg-indigo-500 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button></form></div> )}
                    </div>
                    <div className="flex-shrink-0 flex justify-end gap-2 p-4 border-t dark:border-gray-700"><button type="button" onClick={onClose} className="px-4 py-2 rounded-md border dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700">Close</button></div>
                </div>
            </div>
        );
    };
    
    return (
        <div className={`relative flex flex-col h-screen p-6 ${theme === "dark" ? "bg-gray-900 text-gray-50" : "bg-gray-50 text-gray-900"}`}>
            <MedicalParticles />
            <div className="relative z-10 flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold">Suppliers</h1>
                <button onClick={() => setIsAddModalOpen(true)} className="rounded-md bg-indigo-600 text-white px-3 py-2 text-sm">Add Supplier</button>
            </div>
            
            <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
                <input type="text" placeholder="Search by supplier name..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full sm:w-1/2 rounded-md border bg-transparent px-3 py-2 text-sm dark:border-gray-700"/>
                <select value={sortKey} onChange={(e) => setSortKey(e.target.value)} className="w-full sm:w-auto rounded-md border bg-transparent px-3 py-2 text-sm dark:border-gray-700">
                    <option value="name">Sort by Name</option>
                    <option value="category">Sort by Category</option>
                </select>
            </div>

            <div className="relative z-10 flex-1 overflow-y-auto pr-2">
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 auto-rows-min">
                    {sortedAndFilteredSuppliers.map((s) => (
                        <TiltCard key={s.id} onClick={() => handleViewProfile(s)} className={`rounded-xl p-5 shadow-lg border transition-all hover:shadow-2xl hover:-translate-y-1 cursor-pointer ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                            <div className="flex items-center gap-4 mb-4"><img src={s.avatarUrl} alt={s.name} className="w-16 h-16 rounded-full"/><div><h2 className="text-lg font-semibold">{s.name}</h2><p className="text-sm text-gray-500 dark:text-gray-400">{s.category}</p></div></div>
                            <div className="space-y-2 text-sm"><div className="flex justify-between"><span>Status:</span> <span className="font-semibold">{s.status}</span></div><div className="flex justify-between"><span>Contact:</span> <span className="font-semibold">{s.contactPerson}</span></div></div>
                        </TiltCard>
                    ))}
                </div>
            </div>

            <SupplierProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} supplier={viewingSupplier} onSendMessage={handleSendMessage} />
            <AddSupplierForm isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onSave={handleAddSupplier} />
        </div>
    );
}

export default SuppliersComponent;