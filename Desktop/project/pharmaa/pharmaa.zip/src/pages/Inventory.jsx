import React, { useState, useEffect, useMemo, useRef } from "react";
import { useTheme } from "../components/ThemeContext";
import MedicalParticles from "../components/MedicalParticles";
import TiltCard from "./TiltCard";

export default function Inventory() {
  const { theme } = useTheme();
  const today = new Date().toISOString().split("T")[0];

  const [medicines, setMedicines] = useState(() => {
    try {
      const savedMedicines = localStorage.getItem('medicinesInventory');
      if (savedMedicines) {
        return JSON.parse(savedMedicines);
      }
    } catch (error) {
      console.error("Failed to parse medicines from localStorage", error);
    }
    return [
        { name: "Paracetamol", category: "Pain Relief", stock: 150, price: 2.5, expireDate: "2026-10-20" },
        { name: "Ibuprofen", category: "Pain Relief", stock: 80, price: 3.0, expireDate: "2025-11-15" },
        { name: "Amoxicillin", category: "Antibiotic", stock: 40, price: 5.0, expireDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] },
        { name: "Cetirizine", category: "Antihistamine", stock: 200, price: 1.8, expireDate: "2027-01-01" },
        { name: "Loratadine", category: "Antihistamine", stock: 120, price: 2.1, expireDate: "2028-05-10" },
        { name: "Aspirin", category: "Pain Relief", stock: 30, price: 1.5, expireDate: "2026-02-20" },
        { name: "Omeprazole", category: "Acid Reducer", stock: 90, price: 4.0, expireDate: "2027-08-01" },
    ];
  });

  useEffect(() => {
    try {
        localStorage.setItem('medicinesInventory', JSON.stringify(medicines));
    } catch (error) {
        console.error("Failed to save medicines to localStorage", error);
    }
  }, [medicines]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [notifiedMedicines, setNotifiedMedicines] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'ascending' });
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 6;
  const loaderRef = useRef(null);

  const filteredAndSortedMedicines = useMemo(() => {
    let sortableItems = [...medicines]
      .filter(medicine => (filterCategory === 'all' || medicine.category === filterCategory) && medicine.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'ascending' ? -1 : 1;
        if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [medicines, searchTerm, filterCategory, sortConfig]);

  const totalPages = useMemo(() => Math.ceil(filteredAndSortedMedicines.length / ITEMS_PER_PAGE), [filteredAndSortedMedicines]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const firstEntry = entries[0];
        if (firstEntry.isIntersecting && currentPage < totalPages) {
          setCurrentPage(prev => prev + 1);
        }
      },
      { threshold: 1.0 }
    );
    const currentLoader = loaderRef.current;
    if (currentLoader) observer.observe(currentLoader);
    return () => { if (currentLoader) observer.unobserve(currentLoader); };
  }, [currentPage, totalPages]);

  useEffect(() => {
    if ("Notification" in window) {
      if (Notification.permission !== "granted" && Notification.permission !== "denied") {
        Notification.requestPermission();
      }
    }
  }, []);

  useEffect(() => {
    if (Notification.permission !== "granted") return;
    const expiringSoonNew = [];
    const alreadyNotified = new Set(notifiedMedicines);
    medicines.forEach(medicine => {
      if (!medicine.expireDate) return;
      const expireDate = new Date(medicine.expireDate);
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      const diffTime = expireDate - now;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (diffDays >= 0 && diffDays <= 15 && !alreadyNotified.has(medicine.name)) {
        new Notification("Expiry Warning", { body: `${medicine.name} is expiring in ${diffDays} day(s).`, icon: 'https://img.icons8.com/plasticine/100/pill.png' });
        expiringSoonNew.push(medicine.name);
      }
    });
    if (expiringSoonNew.length > 0) {
      setNotifiedMedicines(prev => [...new Set([...prev, ...expiringSoonNew])]);
    }
  }, [medicines, notifiedMedicines]);

  const saveForm = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newMedicine = { name: formData.get("name") || "", category: formData.get("category") || "", stock: parseInt(formData.get("stock")) || 0, price: parseFloat(formData.get("price")) || 0, expireDate: formData.get("expireDate") || "" };
    if (!e.target.checkValidity()) { e.target.reportValidity(); return; }
    if (editing) {
      setMedicines(prev => prev.map(m => (m.name === editing.name ? { ...m, ...newMedicine } : m)));
    } else {
      setMedicines(prev => [...prev, newMedicine]);
    }
    setModalOpen(false);
    setEditing(null);
  };
  
  const handleDelete = (medicine) => setDeleteConfirm(medicine);
  const confirmDelete = () => {
    if (deleteConfirm) {
      setMedicines(prev => prev.filter(med => med.name !== deleteConfirm.name));
      setDeleteConfirm(null);
    }
  };

  const getStockColor = (stock) => {
    if (stock < 50) return "bg-red-500 text-white border border-red-300";
    if (stock <= 150) return "bg-yellow-400 text-black border border-yellow-300";
    return "bg-green-500 text-white border border-green-300";
  };
  
  const getExpiryWarningClass = (expireDateStr) => {
    if (!expireDateStr) return "";
    const expireDate = new Date(expireDateStr);
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const diffTime = expireDate - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    // UPDATED LOGIC: Changed from <=15 to <15
    if (diffDays >= 0 && diffDays < 15) return "police-light-border";
    return "";
  };
  
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterCategory, sortConfig]);

  const visibleMedicines = useMemo(() => {
    return filteredAndSortedMedicines.slice(0, currentPage * ITEMS_PER_PAGE);
  }, [filteredAndSortedMedicines, currentPage]);

  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') direction = 'descending';
    setSortConfig({ key, direction });
  };
  
  const lowStockCount = useMemo(() => medicines.filter(m => m.stock < 50).length, [medicines]);
  const expiringSoonCount = useMemo(() => medicines.filter(m => getExpiryWarningClass(m.expireDate)).length, [medicines]);
  const categories = useMemo(() => ["all", ...new Set(medicines.map(m => m.category))], [medicines]);

  return (
    <div className="relative">
      <style>{`
        @keyframes modal-pop { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .animate-modal-pop { animation: modal-pop 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        @keyframes police-light-flash { 0% { border-color: #ef4444; } 50% { border-color: #3b82f6; } 100% { border-color: #ef4444; } }
        .police-light-border { animation: police-light-flash 1s infinite; border-width: 2px; border-style: solid; }
        .card-animate { opacity: 0; transform: translateY(30px); transition: opacity 0.5s ease-out, transform 0.5s ease-out; }
        .card-animate.is-visible { opacity: 1; transform: translateY(0); }
      `}</style>
      <MedicalParticles />
      <div className="relative z-10 mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold">Inventory Dashboard</h1>
        <button onClick={() => setModalOpen(true)} className="rounded-md bg-indigo-600 text-white px-4 py-2 text-sm font-semibold hover:scale-105 transition shadow-lg">
          Add Medicine
        </button>
      </div>
      
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div className={`p-4 rounded-xl shadow-md ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-slate-800 text-gray-200'}`}><h3 className="text-lg font-semibold">Total Medicines</h3><p className="text-3xl font-bold">{medicines.length}</p></div>
        <div className={`p-4 rounded-xl shadow-md ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-slate-800 text-gray-200'}`}><h3 className="text-lg font-semibold">Low Stock Items</h3><p className="text-3xl font-bold text-red-500">{lowStockCount}</p></div>
        <div className={`p-4 rounded-xl shadow-md ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-slate-800 text-gray-200'}`}><h3 className="text-lg font-semibold">Expiring Soon</h3><p className="text-3xl font-bold text-yellow-500">{expiringSoonCount}</p></div>
      </div>
      
      <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 ${theme === 'light' ? 'bg-white' : 'bg-slate-800'}`}>
        <input type="text" placeholder="Search by name..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className={`w-full sm:w-1/3 rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300 placeholder:text-gray-500' : 'border-gray-700 text-gray-200 placeholder:text-gray-400'}`} />
        <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className={`w-full sm:w-auto rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700 text-gray-200 bg-slate-800'}`}>
          {categories.map(cat => <option key={cat} value={cat} className={theme === 'dark' ? 'bg-slate-700' : ''}>{cat === 'all' ? 'All Categories' : cat}</option>)}
        </select>
        <div className="flex gap-2">
          <button onClick={() => requestSort('name')} className={`rounded-md border px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300 text-gray-700' : 'border-gray-700 text-gray-300'}`}>
            Sort by Name {sortConfig.key === 'name' ? (sortConfig.direction === 'ascending' ? '▲' : '▼') : ''}
          </button>
          <button onClick={() => requestSort('stock')} className={`rounded-md border px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300 text-gray-700' : 'border-gray-700 text-gray-300'}`}>
            Sort by Stock {sortConfig.key === 'stock' ? (sortConfig.direction === 'ascending' ? '▲' : '▼') : ''}
          </button>
        </div>
      </div>

      <div className="relative z-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visibleMedicines.map((m, i) => {
          const stockColor = getStockColor(m.stock);
          const expiryWarningClass = getExpiryWarningClass(m.expireDate);
          return (
            <TiltCard key={i} className={`rounded-xl p-5 shadow-lg hover:shadow-2xl transition-all cursor-pointer ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-slate-800 text-gray-200'} ${expiryWarningClass}`} onClick={() => { setEditing(m); setModalOpen(true); }}>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-semibold">{m.name}</h2>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${stockColor}`}>{m.stock} in stock</span>
              </div>
              <div className="text-sm space-y-1">
                <p><strong>Category:</strong> {m.category}</p>
                <p><strong>Price:</strong> ${m.price.toFixed(2)}</p>
                <p><strong>Expires:</strong> {m.expireDate}</p>
              </div>
              <div className="flex gap-2 mt-3">
                <button className="flex-1 rounded-md bg-indigo-600 text-white px-3 py-1 text-sm hover:bg-indigo-500" onClick={(e) => { e.stopPropagation(); setEditing(m); setModalOpen(true); }}>Edit</button>
                <button className="flex-1 rounded-md bg-red-600 text-white px-3 py-1 text-sm hover:bg-red-500" onClick={(e) => { e.stopPropagation(); handleDelete(m); }}>Delete</button>
              </div>
            </TiltCard>
          );
        })}
      </div>
      <div ref={loaderRef} className="relative z-10 col-span-1 sm:col-span-2 lg:col-span-3 h-10 flex justify-center items-center">
        {currentPage < totalPages && <p className={`text-sm ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>Loading more medicines...</p>}
      </div>
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { setModalOpen(false); setEditing(null); }} />
          <div className={`relative w-full max-w-lg rounded-xl shadow-2xl ${theme === 'light' ? 'bg-white text-gray-900' : 'bg-slate-800 text-white'}`}>
            <div className={`flex items-center justify-between border-b px-4 py-3 ${theme === 'light' ? 'border-gray-200' : 'border-gray-700'}`}>
              <h3 className="font-semibold text-lg">{editing ? "Edit Item" : "Add Medicine"}</h3>
              <button className={`rounded-full p-1 text-xl h-8 w-8 flex items-center justify-center ${theme === 'light' ? 'hover:bg-gray-200' : 'hover:bg-slate-700'}`} onClick={() => { setModalOpen(false); setEditing(null); }}>✕</button>
            </div>
            <form onSubmit={saveForm} noValidate className="grid grid-cols-1 gap-x-4 gap-y-2 p-4 sm:grid-cols-2">
              <div className="sm:col-span-2"><label className="text-sm font-medium">Name <span className="text-red-500">*</span></label><input name="name" defaultValue={editing?.name || ""} placeholder="e.g., Paracetamol" className={`mt-1 w-full rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`} required /></div>
              <div><label className="text-sm font-medium">Category <span className="text-red-500">*</span></label><input name="category" defaultValue={editing?.category || ""} placeholder="e.g., Pain Relief" className={`mt-1 w-full rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`} required /></div>
              <div><label className="text-sm font-medium">Expire Date <span className="text-red-500">*</span></label><input type="date" min={today} name="expireDate" defaultValue={editing?.expireDate ?? ""} className={`mt-1 w-full rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`} required /></div>
              <div><label className="text-sm font-medium">Price ($) <span className="text-red-500">*</span></label><input type="number" step="0.01" min="0.01" name="price" defaultValue={editing?.price ?? ""} placeholder="e.g., 2.50" className={`mt-1 w-full rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`} required /></div>
              <div><label className="text-sm font-medium">Stock <span className="text-red-500">*</span></label><input type="number" min="0" name="stock" defaultValue={editing?.stock ?? ""} placeholder="e.g., 150" className={`mt-1 w-full rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`} required /></div>
              <div className={`sm:col-span-2 mt-4 flex items-center justify-end gap-2 border-t pt-4 ${theme === 'light' ? 'border-gray-200' : 'border-gray-700'}`}><button type="button" className={`rounded-md border px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300 hover:bg-gray-100' : 'border-gray-700 hover:bg-slate-700'}`} onClick={() => { setModalOpen(false); setEditing(null); }}>Cancel</button><button type="submit" className="rounded-md bg-indigo-600 px-3 py-2 text-sm text-white shadow hover:bg-indigo-500 transition">Save</button></div>
            </form>
          </div>
        </div>
      )}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)} />
          <div className={`relative w-full max-w-sm rounded-xl shadow-2xl ${theme === 'light' ? 'bg-white text-gray-900' : 'bg-slate-800 text-white'}`}>
            <div className="p-6 text-center"><h3 className="text-lg font-semibold mb-2">Are you sure?</h3><p className={`text-sm mb-4 ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>Do you really want to delete "{deleteConfirm.name}"? This process cannot be undone.</p><div className="flex justify-center gap-4"><button onClick={() => setDeleteConfirm(null)} className={`rounded-md border px-4 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700'}`}>Cancel</button><button onClick={confirmDelete} className="rounded-md bg-red-600 text-white px-4 py-2 text-sm shadow">Delete</button></div></div>
          </div>
        </div>
      )}
    </div>
  );
}