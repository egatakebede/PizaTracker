// C:\Users\User\Desktop\pharmaa\src\pages\Settings.jsx
import React, { useState, useEffect, useRef } from "react";
import { useTheme } from "../components/ThemeContext";
import MedicalParticles from "../components/MedicalParticles"; // Import the real MedicalParticles
import { Camera } from "lucide-react";

// --- Main Settings Component ---
function SettingsComponent() {
  const { theme, toggleTheme } = useTheme();
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem("pharmacyProfileV3");
    return saved
      ? JSON.parse(saved)
      : {
          name: "Athanex Pharmacy",
          address: "123 Health St, Addis Ababa, Ethiopia",
          phone: "+251 91 123 4567",
          email: "contact@athanex.com",
          timezone: "Africa/Addis_Ababa",
          currency: "ETB",
          avatarUrl: "https://placehold.co/100x100/A78BFA/FFFFFF?text=AP",
        };
  });

  // Profile Picture States
  const [avatar, setAvatar] = useState(profile.avatarUrl);
  const [cameraModalOpen, setCameraModalOpen] = useState(false);
  const [useCamera, setUseCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [modalError, setModalError] = useState("");
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Staff
  const [staff, setStaff] = useState(() => {
    const saved = localStorage.getItem("pharmacyStaffV3");
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 1,
            name: "Admin User",
            email: "admin@athanex.com",
            role: "Admin",
            status: "Active",
          },
        ];
  });

  // Notifications
  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem("pharmacyNotificationsV3");
    return saved ? JSON.parse(saved) : { email: true, sms: false, push: true };
  });

  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  const cardClasses = `relative rounded-xl p-6 shadow-lg ${
    theme === "dark" ? "bg-slate-800 text-gray-200" : "bg-white text-gray-800"
  }`;
  const inputClasses = `w-full rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
    theme === "dark" ? "bg-slate-700 border-gray-600" : "bg-white border-gray-300"
  }`;
  const labelClasses = `text-sm font-medium ${
    theme === "dark" ? "text-gray-300" : "text-gray-600"
  }`;

  // Profile Picture Handlers
  useEffect(() => {
    const savedAvatar = localStorage.getItem("pharmacyAvatar");
    if (savedAvatar) setAvatar(savedAvatar);
  }, []);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const avatarUrl = reader.result;
        setAvatar(avatarUrl);
        setProfile((prev) => ({ ...prev, avatarUrl }));
        localStorage.setItem("pharmacyAvatar", avatarUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setUseCamera(true);
      setModalError("");
    } catch (err) {
      setModalError("Failed to access camera. Please check permissions.");
    }
  };

  const handleCapturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext("2d").drawImage(videoRef.current, 0, 0);
    const avatarUrl = canvas.toDataURL("image/png");
    setAvatar(avatarUrl);
    setProfile((prev) => ({ ...prev, avatarUrl }));
    localStorage.setItem("pharmacyAvatar", avatarUrl);
    stream.getTracks().forEach((track) => track.stop());
    setStream(null);
    setUseCamera(false);
    setCameraModalOpen(false);
  };

  const handleModalClose = () => {
    setCameraModalOpen(false);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setUseCamera(false);
    setModalError("");
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile((prev) => ({ ...prev, [name]: value }));
  };

  const handleProfileSave = () => {
    localStorage.setItem("pharmacyProfileV3", JSON.stringify(profile));
    alert("Profile saved!");
  };

  const handleAddStaff = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newStaff = {
      id: staff.length + 1,
      name: formData.get("name"),
      email: formData.get("email"),
      role: formData.get("role"),
      status: "Active",
    };
    const updatedStaff = [...staff, newStaff];
    setStaff(updatedStaff);
    localStorage.setItem("pharmacyStaffV3", JSON.stringify(updatedStaff));
    setInviteModalOpen(false);
  };

  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotifications((prev) => {
      const updated = { ...prev, [name]: checked };
      localStorage.setItem("pharmacyNotificationsV3", JSON.stringify(updated));
      return updated;
    });
  };

  const handleClearData = () => {
    localStorage.removeItem("pharmacyProfileV3");
    localStorage.removeItem("pharmacyStaffV3");
    localStorage.removeItem("pharmacyNotificationsV3");
    localStorage.removeItem("pharmacyAvatar");
    setProfile({
      name: "Athanex Pharmacy",
      address: "123 Health St, Addis Ababa, Ethiopia",
      phone: "+251 91 123 4567",
      email: "contact@athanex.com",
      timezone: "Africa/Addis_Ababa",
      currency: "ETB",
      avatarUrl: "https://placehold.co/100x100/A78BFA/FFFFFF?text=AP",
    });
    setAvatar("https://placehold.co/100x100/A78BFA/FFFFFF?text=AP");
    setStaff([{ id: 1, name: "Admin User", email: "admin@athanex.com", role: "Admin", status: "Active" }]);
    setNotifications({ email: true, sms: false, push: true });
    setConfirmModalOpen(false);
  };

  return (
    <div className={`relative flex flex-col h-screen p-6 ${theme === "dark" ? "text-gray-200" : "text-gray-800"}`}>
      <MedicalParticles variant="default" />
      <div className="relative z-10">
        <h1 className="text-3xl font-bold text-blue-600 mb-6">Settings</h1>

        {/* Pharmacy Profile */}
        <div className={cardClasses}>
          <h3 className="text-lg font-semibold mb-4">Pharmacy Profile</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="col-span-2 flex items-center gap-4 mb-4">
              <img src={avatar} alt="Pharmacy Avatar" className="w-20 h-20 rounded-full bg-gray-200" />
              <div>
                <button
                  onClick={() => setCameraModalOpen(true)}
                  className="flex items-center gap-2 rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
                >
                  <Camera className="w-5 h-5" />
                  Change Profile Picture
                </button>
              </div>
            </div>
            <div>
              <label className={labelClasses}>Name</label>
              <input
                name="name"
                value={profile.name}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Address</label>
              <input
                name="address"
                value={profile.address}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Phone</label>
              <input
                name="phone"
                value={profile.phone}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Email</label>
              <input
                name="email"
                value={profile.email}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Timezone</label>
              <input
                name="timezone"
                value={profile.timezone}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Currency</label>
              <input
                name="currency"
                value={profile.currency}
                onChange={handleProfileChange}
                className={inputClasses}
              />
            </div>
          </div>
          <button
            onClick={handleProfileSave}
            className="mt-4 rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
          >
            Save Profile
          </button>
        </div>

        {/* Staff Management */}
        <div className={`${cardClasses} mt-6`}>
          <h3 className="text-lg font-semibold mb-4">Staff Management</h3>
          <div className="space-y-4">
            {staff.map((member) => (
              <div key={member.id} className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">{member.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {member.email} | {member.role} | {member.status}
                  </p>
                </div>
              </div>
            ))}
            <button
              onClick={() => setInviteModalOpen(true)}
              className="mt-4 rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
            >
              Add Staff
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className={`${cardClasses} mt-6`}>
          <h3 className="text-lg font-semibold mb-4">Notifications</h3>
          <div className="space-y-4">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="email"
                checked={notifications.email}
                onChange={handleNotificationChange}
                className="rounded border-gray-300"
              />
              Email Notifications
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="sms"
                checked={notifications.sms}
                onChange={handleNotificationChange}
                className="rounded border-gray-300"
              />
              SMS Notifications
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="push"
                checked={notifications.push}
                onChange={handleNotificationChange}
                className="rounded border-gray-300"
              />
              Push Notifications
            </label>
          </div>
        </div>

        {/* Clear Data */}
        <div className={`${cardClasses} mt-6`}>
          <h3 className="text-lg font-semibold mb-4 text-red-600 dark:text-red-400">Danger Zone</h3>
          <button
            onClick={() => setConfirmModalOpen(true)}
            className="rounded-md bg-red-600 text-white px-4 py-2 text-sm hover:bg-red-500"
          >
            Clear All Data
          </button>
        </div>

        {/* Profile Picture Modal */}
        {cameraModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={handleModalClose} />
            <div className={`${cardClasses} w-full max-w-md`}>
              <h3 className="text-lg font-semibold mb-4">Change Profile Picture</h3>
              {modalError && <p className="text-red-500 text-sm mb-4">{modalError}</p>}
              {!useCamera && (
                <div className="flex flex-col items-center gap-4">
                  <div className="py-10 border-2 border-dashed rounded-lg">
                    <button
                      onClick={() => document.getElementById('avatar-file-input').click()}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-500 mb-2"
                    >
                      Upload Photo
                    </button>
                    <input
                      id="avatar-file-input"
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      className="hidden"
                    />
                    <p className="text-sm my-2">OR</p>
                    <button
                      onClick={startCamera}
                      className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500"
                    >
                      Use Camera
                    </button>
                  </div>
                </div>
              )}
              {useCamera && (
                <div className="flex flex-col items-center gap-4">
                  <h4 className="text-lg font-semibold">Camera</h4>
                  <video ref={videoRef} autoPlay className="w-full h-60 bg-gray-200 dark:bg-slate-700 rounded-md" />
                  <button
                    onClick={handleCapturePhoto}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500"
                  >
                    Capture
                  </button>
                </div>
              )}
              <canvas ref={canvasRef} className="hidden" />
            </div>
          </div>
        )}

        {/* Invite Modal */}
        {inviteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setInviteModalOpen(false)}
            />
            <div className={`${cardClasses} w-full max-w-md`}>
              <h3 className="text-lg font-semibold mb-4">Add Staff Member</h3>
              <form onSubmit={handleAddStaff} className="space-y-4">
                <div>
                  <label className={labelClasses}>Name</label>
                  <input name="name" required className={inputClasses} />
                </div>
                <div>
                  <label className={labelClasses}>Email</label>
                  <input type="email" name="email" required className={inputClasses} />
                </div>
                <div>
                  <label className={labelClasses}>Role</label>
                  <select name="role" required className={inputClasses}>
                    <option>Pharmacist</option>
                    <option>Admin</option>
                    <option>Cashier</option>
                  </select>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setInviteModalOpen(false)}
                    className="px-4 py-2 rounded-md border dark:border-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-md bg-indigo-600 text-white"
                  >
                    Add
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Confirm Modal */}
        {confirmModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setConfirmModalOpen(false)}
            />
            <div className={`${cardClasses} w-full max-w-md text-center`}>
              <h3 className="text-lg font-semibold mb-2">Are you sure?</h3>
              <p className="text-sm text-gray-500 mb-4">
                This will permanently delete all data. This action cannot be undone.
              </p>
              <div className="flex justify-center gap-4">
                <button
                  onClick={() => setConfirmModalOpen(false)}
                  className="px-4 py-2 rounded-md border dark:border-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={handleClearData}
                  className="px-4 py-2 rounded-md bg-red-600 text-white"
                >
                  Yes, Clear Data
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// --- Main App Component ---
export default SettingsComponent;