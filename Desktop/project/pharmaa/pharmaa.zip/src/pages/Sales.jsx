import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useTheme } from "../components/ThemeContext";
import MedicalParticles from "../components/MedicalParticles";

// Custom hook to reliably load external scripts like Leaflet.js
const useScript = (src) => {
    const [status, setStatus] = useState(src ? "loading" : "idle");
    useEffect(() => {
        if (!src) { setStatus("idle"); return; }
        let script = document.querySelector(`script[src="${src}"]`);
        if (!script) {
            script = document.createElement("script");
            script.src = src;
            script.async = true;
            script.setAttribute("data-status", "loading");
            document.body.appendChild(script);
            const setAttributeFromEvent = (event) => {
                script.setAttribute("data-status", event.type === "load" ? "ready" : "error");
            };
            script.addEventListener("load", setAttributeFromEvent);
            script.addEventListener("error", setAttributeFromEvent);
        } else {
            setStatus(script.getAttribute("data-status") || 'ready');
        }
        const setStateFromEvent = (event) => {
            setStatus(event.type === "load" ? "ready" : "error");
        };
        script.addEventListener("load", setStateFromEvent);
        script.addEventListener("error", setStateFromEvent);
        return () => {
            if (script) {
                script.removeEventListener("load", setStateFromEvent);
                script.removeEventListener("error", setStateFromEvent);
            }
        };
    }, [src]);
    return status;
};

// Map Component to display patient location
const MapComponent = ({ location }) => {
    const mapContainerRef = useRef(null);
    const mapInstanceRef = useRef(null);
    const leafletStatus = useScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');
    useEffect(() => {
        if (!document.getElementById('leaflet-css')) {
            const leafletCss = document.createElement('link');
            leafletCss.id = 'leaflet-css';
            leafletCss.rel = 'stylesheet';
            leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
            document.head.appendChild(leafletCss);
        }
    }, []);
    useEffect(() => {
        if (leafletStatus === 'ready' && mapContainerRef.current && location && !mapInstanceRef.current && window.L) {
            mapInstanceRef.current = window.L.map(mapContainerRef.current).setView([location.lat, location.lng], 14);
            window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(mapInstanceRef.current);
            window.L.marker([location.lat, location.lng]).addTo(mapInstanceRef.current);
            setTimeout(() => mapInstanceRef.current.invalidateSize(), 100);
        }
        return () => {
            if (mapInstanceRef.current) {
                mapInstanceRef.current.remove();
                mapInstanceRef.current = null;
            }
        };
    }, [location, leafletStatus]);
    if (leafletStatus === 'loading') return <div className="flex items-center justify-center h-[250px] bg-gray-200 rounded-lg"><p>Loading map...</p></div>;
    if (leafletStatus === 'error') return <div className="flex items-center justify-center h-[250px] bg-red-100 text-red-700 rounded-lg"><p>Error loading map.</p></div>;
    return <div ref={mapContainerRef} style={{ height: '250px', width: '100%', borderRadius: '12px', zIndex: 0 }}></div>;
};

// --- Main Sales Component ---
export default function Sales() {
  const { theme } = useTheme();
  const [orders, setOrders] = useState(() => {
    try {
      const savedOrders = localStorage.getItem('pharmacyPatientOrdersV2');
      if (savedOrders) return JSON.parse(savedOrders);
    } catch (error) { console.error("Failed to parse orders from localStorage", error); }
    return [
      { id: "ORD-101", total: 58.2, date: "2025-08-10", status: "Completed", patient: { name: "John Doe", age: 45, gender: "Male", contact: "+251 91 123 4567", avatarUrl: "https://placehold.co/100x100/E2E8F0/4A5568?text=JD", location: { lat: 9.005401, lng: 38.763611, address: "Bole, Addis Ababa, Ethiopia" } } },
      { id: "ORD-102", total: 92.5, date: "2025-08-11", status: "Pending", patient: { name: "Jane Smith", age: 34, gender: "Female", contact: "+251 92 234 5678", avatarUrl: "https://placehold.co/100x100/E2E8F0/4A5568?text=JS", location: { lat: 8.9806, lng: 38.7578, address: "Old Airport, Addis Ababa, Ethiopia" } } },
      { id: "ORD-103", total: 120.0, date: "2025-08-12", status: "Shipped", patient: { name: "Alice Johnson", age: 62, gender: "Female", contact: "+251 93 345 6789", avatarUrl: "https://placehold.co/100x100/E2E8F0/4A5568?text=AJ", location: { lat: 9.0215, lng: 38.7469, address: "Kazanchis, Addis Ababa, Ethiopia" } } },
    ];
  });
  
  const [modalOpen, setModalOpen] = useState(false);
  const [viewingOrder, setViewingOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    localStorage.setItem('pharmacyPatientOrdersV2', JSON.stringify(orders));
  }, [orders]);

  const openModal = (order) => {
    setViewingOrder(order);
    setModalOpen(true);
  };
  const closeModal = () => setModalOpen(false);

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
      case "Pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "Shipped": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300";
    }
  };

  const getStatusBorderColor = (status) => {
    switch (status) {
      case "Completed": return "border-green-500";
      case "Pending": return "border-yellow-500";
      case "Shipped": return "border-blue-500";
      default: return theme === 'light' ? "border-gray-200" : "border-gray-700";
    }
  };

  const filteredOrders = useMemo(() => orders.filter(order =>
      (filterStatus === "all" || order.status === filterStatus) &&
      (order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
       order.patient.name.toLowerCase().includes(searchTerm.toLowerCase()))
  ), [orders, searchTerm, filterStatus]);
  
  const orderStatuses = useMemo(() => ["all", ...new Set(orders.map(o => o.status))], [orders]);

  return (
    <div className="relative flex flex-col h-full">
      <style>{`@keyframes modal-pop { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } } .animate-modal-pop { animation: modal-pop 0.3s cubic-bezier(0.16, 1, 0.3, 1); }`}</style>
      <MedicalParticles />
      <div className="relative z-10 flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Patient Orders</h1>
      </div>
      <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 ${theme === 'light' ? 'bg-white' : 'bg-slate-800'}`}>
        <input type="text" placeholder="Search by Order ID or Patient Name..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className={`w-full sm:w-1/2 rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300 placeholder:text-gray-500' : 'border-gray-700 text-gray-200 placeholder:text-gray-400'}`} />
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className={`w-full sm:w-auto rounded-md border bg-transparent px-3 py-2 text-sm ${theme === 'light' ? 'border-gray-300' : 'border-gray-700 text-gray-200 bg-slate-800'}`}>
          {orderStatuses.map(status => <option key={status} value={status} className={theme === 'dark' ? 'bg-slate-700' : ''}>{status === 'all' ? 'All Statuses' : status}</option>)}
        </select>
      </div>
      <div className="relative z-10 flex-grow overflow-y-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOrders.map((order) => (
            <div key={order.id} onClick={() => openModal(order)} className={`rounded-xl border-2 shadow-lg transition-all hover:shadow-2xl hover:-translate-y-1 cursor-pointer ${getStatusBorderColor(order.status)} ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-slate-800 text-gray-200'}`}>
              <div className="p-5">
                <div className="flex justify-between items-start">
                  <div>
                    <p className={`text-sm font-semibold ${theme === 'light' ? 'text-indigo-600' : 'text-indigo-400'}`}>{order.id}</p>
                    <p className="font-bold text-lg">{order.patient.name}</p>
                  </div>
                  <span className={`px-2.5 py-0.5 text-xs rounded-full font-semibold ${getStatusColor(order.status)}`}>{order.status}</span>
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <p className={`text-xl font-bold ${theme === 'light' ? 'text-green-600' : 'text-green-400'}`}>{`$${order.total.toFixed(2)}`}</p>
                  <p className={`text-sm ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>{order.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {modalOpen && viewingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={closeModal} />
          <div className={`relative w-full max-w-lg animate-modal-pop rounded-xl shadow-2xl ${theme === 'light' ? 'bg-white text-gray-900' : 'bg-slate-800 text-white'}`}>
            <div className={`flex items-center justify-between border-b px-6 py-4 ${theme === 'light' ? 'border-gray-200' : 'border-gray-700'}`}><h3 className="font-semibold text-lg">Patient & Order Details</h3><button className={`rounded-full p-1 text-xl h-8 w-8 flex items-center justify-center ${theme === 'light' ? 'hover:bg-gray-200' : 'hover:bg-slate-700'}`} onClick={closeModal}>✕</button></div>
            <div className="p-6 max-h-[80vh] overflow-y-auto">
              <div className="flex items-center gap-4">
                <img src={viewingOrder.patient.avatarUrl} alt={viewingOrder.patient.name} className={`w-20 h-20 rounded-full ${theme === 'light' ? 'bg-gray-200' : 'bg-gray-700'}`}/>
                <div>
                  <h4 className="text-xl font-bold">{viewingOrder.patient.name}</h4>
                  <p className={`text-sm ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>{viewingOrder.patient.age} years old, {viewingOrder.patient.gender}</p>
                  <p className={`text-sm ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>{viewingOrder.patient.contact}</p>
                </div>
              </div>
              <div className={`mt-6 pt-4 border-t ${theme === 'light' ? 'border-gray-200' : 'border-gray-700'}`}>
                  <h5 className="font-semibold mb-2">Order: {viewingOrder.id}</h5>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                      <div><p className={`${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>Status</p><p><span className={`px-2 py-1 text-xs rounded-full font-semibold ${getStatusColor(viewingOrder.status)}`}>{viewingOrder.status}</span></p></div>
                      <div><p className={`${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>Date</p><p>{viewingOrder.date}</p></div>
                      <div className="col-span-2"><p className={`${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>Total Amount</p><p className="text-2xl font-bold">{`$${viewingOrder.total.toFixed(2)}`}</p></div>
                  </div>
              </div>
              {viewingOrder.patient.location && (
                <div className={`mt-6 pt-4 border-t ${theme === 'light' ? 'border-gray-200' : 'border-gray-700'}`}>
                  <h5 className="font-semibold mb-2">Patient Location</h5>
                  <p className={`text-sm mb-3 ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}`}>{viewingOrder.patient.location.address}</p>
                  <MapComponent location={viewingOrder.patient.location} />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}