import React, { useState, useEffect, useMemo } from "react";
import { useTheme } from "../components/ThemeContext";

// --- Helper Components ---
const MedicalParticles = () => (
  <div
    style={{
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      zIndex: 0,
      opacity: 0.05,
    }}
  />
);

const useScript = (src) => {
  const [status, setStatus] = useState(src ? "loading" : "idle");
  useEffect(() => {
    if (!src) {
      setStatus("idle");
      return;
    }
    let script = document.querySelector(`script[src="${src}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.setAttribute("data-status", "loading");
      document.body.appendChild(script);
      const setAttributeFromEvent = (event) => {
        script.setAttribute(
          "data-status",
          event.type === "load" ? "ready" : "error"
        );
      };
      script.addEventListener("load", setAttributeFromEvent);
      script.addEventListener("error", setAttributeFromEvent);
    } else {
      setStatus(script.getAttribute("data-status"));
    }
    const setStateFromEvent = (event) => {
      setStatus(event.type === "load" ? "ready" : "error");
    };
    script.addEventListener("load", setStateFromEvent);
    script.addEventListener("error", setStateFromEvent);
    return () => {
      if (script) {
        script.removeEventListener("load", setStateFromEvent);
        script.removeEventListener("error", setStateFromEvent);
      }
    };
  }, [src]);
  return status;
};

// --- Main Reports Component ---
function ReportsComponent() {
  const { theme } = useTheme();
  const [timeRange, setTimeRange] = useState("Today");
  const [activeTab, setActiveTab] = useState("sales");

  // Load external scripts
  const jspdfStatus = useScript(
    "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"
  );
  const autoTableStatus = useScript(
    "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"
  );
  const rechartsStatus = useScript(
    "https://cdnjs.cloudflare.com/ajax/libs/recharts/2.12.7/recharts.min.js"
  );

  const pdfScriptsReady = jspdfStatus === "ready" && autoTableStatus === "ready";

  // Mock data
  const reportData = useMemo(
    () => ({
      Today: {
        sales: {
          totalSales: 475.5,
          totalOrders: 3,
          avgOrderValue: 158.5,
          chartData: [
            { name: "12AM", Sales: 0 },
            { name: "6AM", Sales: 120 },
            { name: "12PM", Sales: 280 },
            { name: "6PM", Sales: 475 },
          ],
        },
        inventory: {
          totalItems: 480,
          stockValue: 12340,
          lowStockCount: 2,
        },
        customers: {
          newCustomers: 1,
          topCustomers: [{ name: "Jane Doe", spent: 215.5 }],
        },
        profit: {
          totalRevenue: 475.5,
          totalExpenses: 200,
          netProfit: 275.5,
        },
      },
      "This Week": {
        sales: {
          totalSales: 3250,
          totalOrders: 18,
          avgOrderValue: 180.5,
          chartData: [
            { name: "Mon", Sales: 400 },
            { name: "Tue", Sales: 600 },
            { name: "Wed", Sales: 550 },
            { name: "Thu", Sales: 800 },
            { name: "Fri", Sales: 900 },
          ],
        },
        inventory: {
          totalItems: 470,
          stockValue: 12100,
          lowStockCount: 5,
        },
        customers: {
          newCustomers: 12,
          topCustomers: [
            { name: "Sam Smith", spent: 1200 },
            { name: "Jane Doe", spent: 950 },
          ],
        },
        profit: {
          totalRevenue: 3250,
          totalExpenses: 1400,
          netProfit: 1850,
        },
      },
      "This Month": {
        sales: {
          totalSales: 12850,
          totalOrders: 95,
          avgOrderValue: 135.2,
          chartData: [
            { name: "Week 1", Sales: 3100 },
            { name: "Week 2", Sales: 2900 },
            { name: "Week 3", Sales: 3400 },
            { name: "Week 4", Sales: 3450 },
          ],
        },
        inventory: {
          totalItems: 460,
          stockValue: 11800,
          lowStockCount: 10,
        },
        customers: {
          newCustomers: 40,
          topCustomers: [
            { name: "Alice Brown", spent: 2400 },
            { name: "Sam Smith", spent: 1900 },
          ],
        },
        profit: {
          totalRevenue: 12850,
          totalExpenses: 6800,
          netProfit: 6050,
        },
      },
    }),
    []
  );

  const activeReport = reportData[timeRange] || {};

  const exportPDF = () => {
    if (!pdfScriptsReady) return;
    const doc = new window.jspdf.jsPDF();
    doc.setFontSize(22);
    doc.text("Athanex Pharmacy", 14, 22);
    doc.save(`Athanex_${activeTab}_Report_${timeRange}.pdf`);
  };

  return (
    <div className={`relative flex flex-col h-screen p-6 ${theme === "dark" ? "text-gray-200" : "text-gray-800"}`}>
      <MedicalParticles />
      <div className="relative z-10 flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold text-blue-600">
          Reports & Analytics
        </h1>
        <button
          onClick={exportPDF}
          disabled={!pdfScriptsReady}
          className="rounded-md bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-4 py-2 text-sm font-semibold flex items-center gap-2 hover:opacity-90 transition disabled:opacity-50"
        >
          Export to PDF
        </button>
      </div>

      <div className={`relative z-10 p-4 rounded-xl shadow-md mb-6 flex flex-col sm:flex-row gap-4 justify-between items-center ${theme === "dark" ? "bg-slate-800" : "bg-gradient-to-r from-green-100 to-blue-100"}`}>
        <div>
          <span className="font-semibold mr-4">Report Type:</span>
          {["sales", "inventory", "customers", "profit"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 rounded-full text-sm capitalize transition ${
                activeTab === tab
                  ? "bg-blue-500 text-white shadow-md"
                  : "bg-blue-200 text-blue-800 hover:bg-blue-300"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div>
          <span className="font-semibold mr-4">Time Period:</span>
          {["Today", "This Week", "This Month"].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 rounded-full text-sm transition ${
                timeRange === range
                  ? "bg-green-500 text-white shadow-md"
                  : "bg-green-200 text-green-800 hover:bg-green-300"
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      <div className="relative z-10 flex-1 overflow-y-auto pr-2">
        {activeTab === "sales" && activeReport.sales && (
          <SalesOverview data={activeReport.sales} chartStatus={rechartsStatus} theme={theme} />
        )}
        {activeTab === "inventory" && activeReport.inventory && (
          <InventoryOverview data={activeReport.inventory} theme={theme} />
        )}
        {activeTab === "customers" && activeReport.customers && (
          <CustomerOverview data={activeReport.customers} theme={theme} />
        )}
        {activeTab === "profit" && activeReport.profit && (
          <ProfitOverview data={activeReport.profit} chartStatus={rechartsStatus} theme={theme} />
        )}
      </div>
    </div>
  );
}

// --- Sub Components ---
const SalesOverview = ({ data, chartStatus, theme }) => {
  if (chartStatus !== "ready") {
    return <p>Loading chart...</p>;
  }
  const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } =
    window.Recharts;
  return (
    <div className={`p-5 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
      <h3 className="font-semibold mb-4 text-indigo-600">Sales Overview</h3>
      <div className="grid grid-cols-3 gap-4 mb-4">
        <StatCard label="Total Sales" value={`$${data.totalSales}`} theme={theme} />
        <StatCard label="Total Orders" value={data.totalOrders} theme={theme} />
        <StatCard label="Avg Order Value" value={`$${data.avgOrderValue}`} theme={theme} />
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data.chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="Sales" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

const InventoryOverview = ({ data, theme }) => (
  <div className={`p-5 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
    <h3 className="font-semibold mb-4 text-indigo-600">Inventory Overview</h3>
    <div className="grid grid-cols-3 gap-4">
      <StatCard label="Total Items" value={data.totalItems} theme={theme} />
      <StatCard label="Stock Value" value={`$${data.stockValue}`} theme={theme} />
      <StatCard label="Low Stock Count" value={data.lowStockCount} theme={theme} />
    </div>
  </div>
);

const CustomerOverview = ({ data, theme }) => (
  <div className={`p-5 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
    <h3 className="font-semibold mb-4 text-indigo-600">Customer Overview</h3>
    <div className="grid grid-cols-2 gap-4 mb-4">
      <StatCard label="New Customers" value={data.newCustomers} theme={theme} />
      <StatCard
        label="Top Customer"
        value={`${data.topCustomers[0].name} - $${data.topCustomers[0].spent}`}
        theme={theme}
      />
    </div>
  </div>
);

const ProfitOverview = ({ data, chartStatus, theme }) => {
  if (chartStatus !== "ready") return <p>Loading chart...</p>;
  const { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } =
    window.Recharts;
  return (
    <div className={`p-5 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
      <h3 className="font-semibold mb-4 text-indigo-600">Profit Overview</h3>
      <div className="grid grid-cols-3 gap-4 mb-4">
        <StatCard label="Total Revenue" value={`$${data.totalRevenue}`} theme={theme} />
        <StatCard label="Total Expenses" value={`$${data.totalExpenses}`} theme={theme} />
        <StatCard label="Net Profit" value={`$${data.netProfit}`} theme={theme} />
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={[data]}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="label" hide />
          <YAxis />
          <Tooltip />
          <Bar dataKey="totalRevenue" fill="#3b82f6" name="Revenue" />
          <Bar dataKey="totalExpenses" fill="#ef4444" name="Expenses" />
          <Bar dataKey="netProfit" fill="#22c55e" name="Profit" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

const StatCard = ({ label, value, theme }) => (
  <div className={`p-4 rounded-lg text-center shadow ${theme === "dark" ? "bg-slate-700" : "bg-gradient-to-r from-blue-100 to-green-100"}`}>
    <p className={`text-sm font-medium ${theme === "dark" ? "text-gray-300" : "text-gray-600"}`}>{label}</p>
    <p className={`text-lg font-bold ${theme === "dark" ? "text-white" : "text-gray-800"}`}>{value}</p>
  </div>
);

export default function Reports() {
  return <ReportsComponent />;
}