// C:\Users\User\Desktop\pharmaa\src\components\Topbar.jsx
import React, { useState, useRef, useEffect } from "react";
import { Camera, Bell, Stethoscope, Moon, Sun, Search } from "lucide-react";
import { useTheme } from "./ThemeContext";
import MedicalParticles from "./MedicalParticles"; // Import the real MedicalParticles

export default function Topbar() {
  const { theme, toggleTheme } = useTheme();
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [avatar, setAvatar] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [cameraModalOpen, setCameraModalOpen] = useState(false);
  const [medicineData, setMedicineData] = useState({ photoUrl: "", price: 0 });
  const [useCamera, setUseCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [modalError, setModalError] = useState("");
  const [modalSuccess, setModalSuccess] = useState("");
  const [modalStep, setModalStep] = useState('initial');

  // New Search Bar State
  const [searchTerm, setSearchTerm] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const searchRef = useRef(null);

  const [profileData, setProfileData] = useState({
    name: "Alex Williams",
    username: "@alexpharma",
    bio: "Passionate about healthcare & pharma innovation.",
  });
  const [tempProfileData, setTempProfileData] = useState(profileData);

  const [notifications, setNotifications] = useState([
    { id: 1, message: "New order received from John Doe", time: "5 min ago", read: false },
    { id: 2, message: "Inventory low: Paracetamol", time: "1 hr ago", read: false },
    { id: 3, message: "Prescription #1234 approved", time: "2 hrs ago", read: true },
  ]);

  // Mock data for search (medicines, customers, orders)
  const searchData = [
    { type: "medicine", name: "Paracetamol", id: 1, details: "500mg, 100 tablets" },
    { type: "medicine", name: "Ibuprofen", id: 2, details: "200mg, 50 tablets" },
    { type: "customer", name: "John Doe", id: 1, details: "Customer ID: C123" },
    { type: "customer", name: "Jane Smith", id: 2, details: "Customer ID: C124" },
    { type: "order", name: "Order #1234", id: 1, details: "Placed: 2025-09-15" },
  ];

  const filteredSearchResults = searchData.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.details.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const notifRef = useRef(null);
  const profileRef = useRef(null);

  useEffect(() => {
    const savedAvatar = localStorage.getItem("userAvatar");
    const savedProfile = localStorage.getItem("userProfile");
    if (savedAvatar) setAvatar(savedAvatar);
    if (savedProfile) {
      const parsed = JSON.parse(savedProfile);
      setProfileData(parsed);
      setTempProfileData(parsed);
    }
  }, []);

  const handleModalClose = () => {
    setCameraModalOpen(false);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setTimeout(() => {
      setMedicineData({ photoUrl: "", price: 0 });
      setUseCamera(false);
      setModalError("");
      setModalSuccess("");
      setModalStep('initial');
    }, 300);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setUseCamera(true);
      setModalError("");
    } catch (err) {
      setModalError("Failed to access camera. Please check permissions.");
    }
  };

  const handleCapturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext("2d").drawImage(videoRef.current, 0, 0);
    const photoUrl = canvas.toDataURL("image/png");
    setMedicineData((prev) => ({ ...prev, photoUrl }));
    stream.getTracks().forEach((track) => track.stop());
    setStream(null);
    setUseCamera(false);
  };

  const handleMedicinePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setMedicineData((prev) => ({ ...prev, photoUrl: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMedicinePriceChange = (e) => {
    setMedicineData((prev) => ({ ...prev, price: e.target.value }));
  };

  const handleSaveMedicine = () => {
    if (!medicineData.photoUrl || !medicineData.price) {
      setModalError("Please provide both a photo and a price.");
      return;
    }
    setModalSuccess("Medicine added to inventory!");
    setTimeout(() => {
      handleModalClose();
    }, 1000);
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setTempProfileData((prev) => ({ ...prev, [name]: value }));
  };

  const handleProfileSave = () => {
    setProfileData(tempProfileData);
    localStorage.setItem("userProfile", JSON.stringify(tempProfileData));
    setIsEditing(false);
    setProfileOpen(false);
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAvatar(reader.result);
        localStorage.setItem("userAvatar", reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notifRef.current && !notifRef.current.contains(event.target)) setNotifOpen(false);
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileOpen(false);
        setIsEditing(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target)) setSearchOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearchSelect = (item) => {
    console.log(`Selected ${item.type}: ${item.name}`);
    setSearchTerm("");
    setSearchOpen(false);
  };

  return (
    <header className={`relative flex items-center justify-between p-4 border-b ${theme === "dark" ? "bg-slate-900 border-gray-700" : "bg-gray-50 border-gray-200"}`}>
      <MedicalParticles variant="default" /> {/* Standardized MedicalParticles */}
      <div className="flex items-center gap-4">
        <Stethoscope className="w-6 h-6 text-indigo-600" />
        <h1 className="text-lg font-semibold">AthaNex</h1>
      </div>
      <div className="flex items-center gap-4 relative z-10">
        {/* Search Bar */}
        <div className="relative" ref={searchRef}>
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search medicines, customers, orders..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setSearchOpen(true);
              }}
              className={`rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                theme === "dark" ? "bg-slate-700 border-gray-600 text-gray-200" : "bg-white border-gray-300 text-gray-800"
              }`}
            />
          </div>
          {searchOpen && searchTerm && filteredSearchResults.length > 0 && (
            <div className={`absolute right-0 mt-2 w-80 rounded-xl shadow-lg p-4 max-h-96 overflow-y-auto ${
              theme === "dark" ? "bg-slate-800 text-gray-200" : "bg-white text-gray-800"
            }`}>
              <h3 className="text-sm font-semibold mb-2">Search Results</h3>
              {filteredSearchResults.map((item) => (
                <div
                  key={`${item.type}-${item.id}`}
                  onClick={() => handleSearchSelect(item)}
                  className={`p-2 rounded-md text-sm cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900`}
                >
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{item.details}</p>
                </div>
              ))}
            </div>
          )}
        </div>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
          title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
        >
          {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 relative"
          >
            <Bell className="w-5 h-5" />
            {notifications.some((n) => !n.read) && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">
                {notifications.filter((n) => !n.read).length}
              </span>
            )}
          </button>
          {notifOpen && (
            <div className={`absolute right-0 mt-2 w-80 rounded-xl shadow-lg p-4 ${theme === "dark" ? "bg-slate-800 text-gray-200" : "bg-white text-gray-800"}`}>
              <h3 className="text-sm font-semibold mb-2">Notifications</h3>
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-2 rounded-md text-sm ${notif.read ? "opacity-50" : "bg-indigo-50 dark:bg-indigo-900"}`}
                >
                  <p>{notif.message}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{notif.time}</p>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2"
          >
            <img
              src={avatar || "https://placehold.co/40x40"}
              alt="User"
              className="w-10 h-10 rounded-full"
            />
            <span className="text-sm font-medium">{profileData.name}</span>
          </button>
          {profileOpen && (
            <div className={`absolute right-0 mt-2 w-64 rounded-xl shadow-lg p-4 ${theme === "dark" ? "bg-slate-800 text-gray-200" : "bg-white text-gray-800"}`}>
              {isEditing ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    name="name"
                    value={tempProfileData.name}
                    onChange={handleProfileChange}
                    className="w-full rounded-md border px-3 py-2 text-sm dark:bg-slate-700 dark:border-gray-600"
                    placeholder="Name"
                  />
                  <input
                    type="text"
                    name="username"
                    value={tempProfileData.username}
                    onChange={handleProfileChange}
                    className="w-full rounded-md border px-3 py-2 text-sm dark:bg-slate-700 dark:border-gray-600"
                    placeholder="Username"
                  />
                  <textarea
                    name="bio"
                    value={tempProfileData.bio}
                    onChange={handleProfileChange}
                    className="w-full rounded-md border px-3 py-2 text-sm dark:bg-slate-700 dark:border-gray-600"
                    placeholder="Bio"
                  />
                  <button
                    onClick={() => document.getElementById('avatar-file-input').click()}
                    className="w-full rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
                  >
                    Change Avatar
                  </button>
                  <input
                    id="avatar-file-input"
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    className="hidden"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1 rounded-md border dark:border-gray-600"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleProfileSave}
                      className="px-3 py-1 rounded-md bg-indigo-600 text-white"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-sm font-semibold">{profileData.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{profileData.username}</p>
                  <p className="text-sm">{profileData.bio}</p>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="w-full rounded-md bg-indigo-600 text-white px-4 py-2 text-sm hover:bg-indigo-500"
                  >
                    Edit Profile
                  </button>
                  <button
                    onClick={() => setCameraModalOpen(true)}
                    className="w-full rounded-md bg-blue-600 text-white px-4 py-2 text-sm hover:bg-blue-500 flex items-center justify-center gap-2"
                  >
                    <Camera className="w-5 h-5" />
                    Add Medicine
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Medicine Modal */}
      {cameraModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={handleModalClose} />
          <div className={`w-full max-w-md rounded-xl p-6 ${theme === "dark" ? "bg-slate-800 text-gray-200" : "bg-white text-gray-800"}`}>
            <h3 className="text-lg font-semibold mb-4">Add Medicine to Inventory</h3>
            {modalSuccess && <p className="text-green-500 text-sm mb-4">{modalSuccess}</p>}
            {modalError && <p className="text-red-500 text-sm mb-4">{modalError}</p>}
            {modalStep === 'initial' && !useCamera && (
              <div className="flex flex-col items-center gap-4">
                <div className="py-10 border-2 border-dashed rounded-lg">
                  <button
                    onClick={() => document.getElementById('medicine-file-input').click()}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-500 mb-2"
                  >
                    Upload Photo
                  </button>
                  <input
                    id="medicine-file-input"
                    type="file"
                    accept="image/*"
                    onChange={handleMedicinePhotoChange}
                    className="hidden"
                  />
                  <p className="text-sm my-2">OR</p>
                  <button
                    onClick={startCamera}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500"
                  >
                    Use Camera
                  </button>
                </div>
              </div>
            )}
            {useCamera && (
              <div className="flex flex-col items-center gap-4">
                <h4 className="text-lg font-semibold">Camera</h4>
                <video
                  ref={videoRef}
                  autoPlay
                  className="w-full h-60 bg-gray-200 dark:bg-slate-700 rounded-md"
                />
                <button
                  onClick={handleCapturePhoto}
                  className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500"
                >
                  Capture
                </button>
              </div>
            )}
            {medicineData.photoUrl && !useCamera && (
              <div>
                <h4 className="text-lg font-semibold mb-4">Confirm Medicine Details</h4>
                <img
                  src={medicineData.photoUrl}
                  alt="medicine"
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <div className="space-y-4">
                  <div>
                    <label className="text-sm">Price*</label>
                    <input
                      type="number"
                      placeholder="0.00"
                      value={medicineData.price || ''}
                      onChange={handleMedicinePriceChange}
                      className="border w-full px-3 py-2 rounded-md dark:bg-slate-700 mt-1"
                    />
                  </div>
                </div>
                <button
                  onClick={handleSaveMedicine}
                  className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500 w-full mt-6"
                >
                  Add to Inventory
                </button>
              </div>
            )}
            <canvas ref={canvasRef} className="hidden" />
          </div>
        </div>
      )}
    </header>
  );
}