import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

import Layout from "./src/components/Layout";
import Dashboard from "./src/pages/Dashboard";
import Inventory from "./src/pages/Inventory";
import Sales from "./src/pages/Sales";
import Prescriptions from "./src/pages/Prescriptions";
import Customers from "./src/pages/Customers";
import Suppliers from "./src/pages/Suppliers";
import Reports from "./src/pages/Reports";
import Settings from "./src/pages/Settings";
import NotFound from "./src/pages/NotFound";
import { ThemeProvider } from "./src/components/ThemeContext";


const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "inventory", element: <Inventory /> },
      { path: "sales", element: <Sales /> },
      { path: "prescriptions", element: <Prescriptions /> },
      { path: "customers", element: <Customers /> },
      { path: "suppliers", element: <Suppliers /> },
      { path: "reports", element: <Reports /> },
      { path: "settings", element: <Settings /> },
      { path: "*", element: <NotFound /> },
    ],
  },
]);


createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ThemeProvider>
      <RouterProvider router={router} />
    </ThemeProvider>
  </StrictMode>
);